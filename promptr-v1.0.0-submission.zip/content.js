// Promptr Extension - Content Script (Refactored)
// Generated: 2025-08-02T21:27:57.040Z
// Modules: TextSelection, TextReplacement, VisualFeedback, ModalSystem, SiteHandlers
(() => {
  // src/content/constants.js
  var SITES = {
    PERPLEXITY: "www.perplexity.ai",
    T3_CHAT: ["t3.chat", "www.t3.chat"],
    CHATGPT: ["chat.openai.com", "chatgpt.com"],
    CLAUDE: "claude.ai",
    GEMINI: "gemini.google.com",
    CURSOR: "cursor.com"
  };
  var SELECTORS = {
    TEXT_INPUTS: [
      "textarea",
      'input[type="text"]',
      '[contenteditable="true"]',
      '[role="textbox"]',
      ".chat-input",
      ".message-input",
      "#message-input",
      "div[contenteditable]"
    ],
    INPUT_TYPES: ["text", "textarea", "email", "search", "url"]
  };
  var TIMING = {
    ANIMATION_DURATION: 600,
    NOTIFICATION_TIMEOUT: 3e3,
    SITE_DETECTION_DELAY: 1e3,
    REACT_EVENT_DELAY: 50,
    FOCUS_DELAY: 10
  };
  var Z_INDEX = {
    NOTIFICATION: 1e4,
    MODAL_OVERLAY: 999999,
    REPLACEMENT_OVERLAY: 999999
  };
  var CSS_CLASSES = {
    MODAL_OVERLAY: "prompter-modal-overlay",
    MODAL: "prompter-modal",
    TEMPLATE_ITEM: "prompter-template-item",
    TEMPLATE_SELECTED: "selected",
    REPLACEMENT_OVERLAY: "prompter-replacement-overlay",
    TRANSITION_STYLES: "prompter-transition-styles",
    MODAL_STYLES: "prompter-modal-styles"
  };
  var EVENTS = {
    INPUT_EVENTS: ["input", "change", "keyup", "paste"],
    FOCUS_EVENTS: ["blur", "focus"],
    PERPLEXITY_EVENTS: ["input", "change", "blur", "focus", "keyup"]
  };
  var COLORS = {
    ERROR: "oklch(0.629 0.1902 23.0704)",
    SUCCESS: "oklch(0.7176 0.1686 142.495)",
    INFO: "oklch(0.5393 0.2713 286.7462)",
    WHITE: "oklch(1 0 0)",
    PURPLE_GLOW: "rgba(139, 92, 246, 0.5)",
    PURPLE_GLOW_STRONG: "rgba(139, 92, 246, 0.8)"
  };
  var ACTIONS = {
    REPLACE_TEXT: "replaceText",
    SHOW_LOADING: "showLoading",
    SHOW_ERROR: "showError",
    SHOW_KEYBOARD_MODAL: "showKeyboardModal",
    FORMAT_WITH_TEMPLATE: "formatWithTemplate",
    TEXT_SELECTED: "textSelected"
  };
  var NOTIFICATION_TYPES = {
    ERROR: "error",
    SUCCESS: "success",
    INFO: "info"
  };

  // src/content/utils.js
  function detectCurrentSite() {
    const hostname = window.location.hostname;
    return {
      isPerplexity: hostname === SITES.PERPLEXITY,
      isT3Chat: SITES.T3_CHAT.includes(hostname),
      isChatGPT: SITES.CHATGPT.includes(hostname),
      isClaude: hostname === SITES.CLAUDE,
      isGemini: hostname === SITES.GEMINI,
      isCursor: hostname === SITES.CURSOR
    };
  }
  function isTextInput(element) {
    if (!element)
      return false;
    const tagName = element.tagName.toLowerCase();
    if (tagName === "textarea")
      return true;
    if (tagName === "input" && SELECTORS.INPUT_TYPES.includes(element.type)) {
      return true;
    }
    if (element.contentEditable === "true")
      return true;
    let parent = element.parentElement;
    while (parent) {
      if (parent.contentEditable === "true")
        return true;
      parent = parent.parentElement;
    }
    return false;
  }
  function findEditableParent(node) {
    let currentNode = node;
    while (currentNode && currentNode !== document) {
      if (currentNode.nodeType === Node.ELEMENT_NODE) {
        const element = (
          /** @type {HTMLElement} */
          currentNode
        );
        if (element.tagName.toLowerCase() === "textarea" || element.tagName.toLowerCase() === "input" || element.contentEditable === "true") {
          return element;
        }
      }
      currentNode = currentNode.parentNode;
    }
    const hostname = window.location.hostname;
    if (hostname === "t3.chat") {
      const chatInput = document.querySelector("#chat-input");
      if (chatInput && isTextInput(chatInput)) {
        return chatInput;
      }
    }
    if (node && node.nodeType === Node.ELEMENT_NODE) {
      const element = (
        /** @type {HTMLElement} */
        node
      );
      const searchRoot = element.closest(
        'form, [role="main"], main, .chat-container, .message-container'
      ) || document.body;
      for (const selector of SELECTORS.TEXT_INPUTS) {
        const input = searchRoot.querySelector(selector);
        if (input && isTextInput(input)) {
          return input;
        }
      }
    }
    return null;
  }
  function getCurrentSelection() {
    const selection = window.getSelection();
    const selectedText = selection.toString().trim();
    if (!selectedText || selectedText.length === 0) {
      return null;
    }
    let targetElement = null;
    let anchorNode = null;
    let selectionRange = null;
    if (selection.anchorNode) {
      anchorNode = selection.anchorNode;
      targetElement = selection.anchorNode.parentElement || selection.anchorNode;
    }
    if (selection.rangeCount > 0) {
      selectionRange = selection.getRangeAt(0).cloneRange();
    }
    const isInInputField = isTextInput(targetElement);
    return {
      text: selectedText,
      element: targetElement,
      // Parent element for display/manipulation
      anchorNode,
      // Actual selection node for findEditableParent
      range: selectionRange,
      isInInputField
    };
  }
  function findEditableElementBySelectors(customSelectors = []) {
    const selectors = [...SELECTORS.TEXT_INPUTS, ...customSelectors];
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element && isTextInput(element)) {
        return element;
      }
    }
    return null;
  }
  function getElementBounds(element) {
    const rect = element.getBoundingClientRect();
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
    return {
      top: rect.top + scrollTop,
      left: rect.left + scrollLeft,
      width: rect.width,
      height: rect.height,
      scrollTop,
      scrollLeft
    };
  }
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }
  function dispatchEvents(element, eventTypes, eventOptions = { bubbles: true }) {
    eventTypes.forEach((eventType) => {
      element.dispatchEvent(new Event(eventType, eventOptions));
    });
  }
  function dispatchReactInputEvent(element, data) {
    const inputEvent = new InputEvent("input", {
      bubbles: true,
      cancelable: true,
      inputType: "insertText",
      data
    });
    element.dispatchEvent(inputEvent);
  }
  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // src/content/modules/domSafety.js
  var DOMSafetyManager = class {
    constructor() {
      this.validatedElements = /* @__PURE__ */ new Set();
    }
    /**
     * Safely checks if an element exists and is valid
     * @param {HTMLElement|null} element - Element to validate
     * @param {boolean} requireAttached - Whether element must be attached to DOM
     * @returns {boolean} True if element is valid
     */
    isValidElement(element, requireAttached = false) {
      try {
        if (!element)
          return false;
        if (!(element instanceof HTMLElement))
          return false;
        if (requireAttached && !element.parentNode && !document.contains(element)) {
          return false;
        }
        return true;
      } catch (error) {
        console.warn("Element validation failed:", error);
        return false;
      }
    }
    /**
     * Checks if element is valid and attached to DOM
     * @param {HTMLElement|null} element - Element to validate
     * @returns {boolean} True if element is valid and attached
     */
    isValidAttachedElement(element) {
      return this.isValidElement(element, true);
    }
    /**
     * Safely queries for an element with timeout and retries
     * @param {string} selector - CSS selector
     * @param {Object} options - Query options
     * @param {number} options.timeout - Maximum wait time in ms
     * @param {number} options.retries - Number of retry attempts
     * @param {HTMLElement} options.context - Context element to search within
     * @returns {Promise<HTMLElement|null>} Found element or null
     */
    async safeQuerySelector(selector, options = {}) {
      const {
        timeout = 5e3,
        retries = 3,
        context = document
      } = options;
      if (!selector || typeof selector !== "string") {
        console.warn("Invalid selector provided:", selector);
        return null;
      }
      for (let attempt = 0; attempt <= retries; attempt++) {
        try {
          if (!this.isValidElement(context) && context !== document) {
            console.warn("Invalid context element");
            return null;
          }
          const element = context.querySelector(selector);
          if (this.isValidElement(element)) {
            this.validatedElements.add(element);
            return element;
          }
          if (attempt < retries) {
            await this.wait(Math.min(100 * Math.pow(2, attempt), 1e3));
          }
        } catch (error) {
          console.warn(`Query attempt ${attempt + 1} failed:`, error);
          if (attempt === retries) {
            return null;
          }
        }
      }
      return null;
    }
    /**
     * Safely queries for multiple elements
     * @param {string} selector - CSS selector
     * @param {Object} options - Query options
     * @returns {Promise<HTMLElement[]>} Array of found elements
     */
    async safeQuerySelectorAll(selector, options = {}) {
      const { context = document } = options;
      try {
        if (!selector || typeof selector !== "string") {
          console.warn("Invalid selector provided:", selector);
          return [];
        }
        if (!this.isValidElement(context) && context !== document) {
          console.warn("Invalid context element");
          return [];
        }
        const elements = Array.from(context.querySelectorAll(selector));
        return elements.filter((el) => this.isValidElement(el));
      } catch (error) {
        console.warn("Query all failed:", error);
        return [];
      }
    }
    /**
     * Safely adds event listener with automatic cleanup
     * @param {HTMLElement} element - Target element
     * @param {string} event - Event type
     * @param {Function} handler - Event handler
     * @param {Object|boolean} options - Event options
     * @returns {Function|null} Cleanup function or null if failed
     */
    safeAddEventListener(element, event, handler, options = {}) {
      try {
        if (!this.isValidElement(element)) {
          console.warn("Cannot add event listener to invalid element");
          return null;
        }
        if (typeof handler !== "function") {
          console.warn("Event handler must be a function");
          return null;
        }
        const wrappedHandler = (e) => {
          try {
            handler(e);
          } catch (error) {
            console.error(`Event handler error for ${event}:`, error);
          }
        };
        element.addEventListener(event, wrappedHandler, options);
        return () => {
          try {
            if (this.isValidElement(element)) {
              element.removeEventListener(event, wrappedHandler, options);
            }
          } catch (error) {
            console.warn("Failed to remove event listener:", error);
          }
        };
      } catch (error) {
        console.warn("Failed to add event listener:", error);
        return null;
      }
    }
    /**
     * Safely modifies element content with validation
     * @param {HTMLElement} element - Target element
     * @param {string} content - Content to set
     * @param {string} method - Method to use ('textContent', 'innerHTML', 'innerText')
     * @returns {boolean} True if successful
     */
    safeSetContent(element, content, method = "textContent") {
      try {
        if (!this.isValidElement(element)) {
          console.warn("Cannot set content on invalid element");
          return false;
        }
        if (typeof content !== "string") {
          console.warn("Content must be a string");
          return false;
        }
        switch (method) {
          case "textContent":
            element.textContent = content;
            break;
          case "innerHTML":
            element.innerHTML = this.sanitizeHTML(content);
            break;
          case "innerText":
            element.innerText = content;
            break;
          default:
            console.warn(`Unknown content method: ${method}`);
            return false;
        }
        return true;
      } catch (error) {
        console.warn(`Failed to set content using ${method}:`, error);
        return false;
      }
    }
    /**
     * Safely modifies element attributes
     * @param {HTMLElement} element - Target element
     * @param {string} attribute - Attribute name
     * @param {string} value - Attribute value
     * @returns {boolean} True if successful
     */
    safeSetAttribute(element, attribute, value) {
      try {
        if (!this.isValidElement(element)) {
          console.warn("Cannot set attribute on invalid element");
          return false;
        }
        if (typeof attribute !== "string" || typeof value !== "string") {
          console.warn("Attribute name and value must be strings");
          return false;
        }
        element.setAttribute(attribute, value);
        return true;
      } catch (error) {
        console.warn(`Failed to set attribute ${attribute}:`, error);
        return false;
      }
    }
    /**
     * Safely removes element from DOM
     * @param {HTMLElement} element - Element to remove
     * @returns {boolean} True if successful
     */
    safeRemoveElement(element) {
      try {
        if (!this.isValidAttachedElement(element)) {
          return false;
        }
        if (element.parentNode) {
          element.parentNode.removeChild(element);
        } else {
          element.remove();
        }
        this.validatedElements.delete(element);
        return true;
      } catch (error) {
        console.warn("Failed to remove element:", error);
        return false;
      }
    }
    /**
     * Safely focuses an element with validation
     * @param {HTMLElement} element - Element to focus
     * @param {Object} options - Focus options
     * @returns {boolean} True if successful
     */
    safeFocus(element, options = {}) {
      try {
        if (!this.isValidElement(element)) {
          console.warn("Cannot focus invalid element");
          return false;
        }
        if (typeof element.focus !== "function") {
          console.warn("Element is not focusable");
          return false;
        }
        element.focus(options);
        return true;
      } catch (error) {
        console.warn("Failed to focus element:", error);
        return false;
      }
    }
    /**
     * Safely checks element visibility
     * @param {HTMLElement} element - Element to check
     * @returns {boolean} True if element is visible
     */
    isElementVisible(element) {
      try {
        if (!this.isValidElement(element)) {
          return false;
        }
        const style = window.getComputedStyle(element);
        return !!(element.offsetWidth || element.offsetHeight || element.getClientRects().length) && style.visibility !== "hidden" && style.display !== "none";
      } catch (error) {
        console.warn("Failed to check element visibility:", error);
        return false;
      }
    }
    /**
     * Safely gets element bounds
     * @param {HTMLElement} element - Element to measure
     * @returns {DOMRect|null} Element bounds or null if failed
     */
    safeGetBounds(element) {
      try {
        if (!this.isValidElement(element)) {
          return null;
        }
        return element.getBoundingClientRect();
      } catch (error) {
        console.warn("Failed to get element bounds:", error);
        return null;
      }
    }
    /**
     * Basic HTML sanitization to prevent XSS
     * @param {string} html - HTML to sanitize
     * @returns {string} Sanitized HTML
     * @private
     */
    sanitizeHTML(html) {
      const div = document.createElement("div");
      div.textContent = html;
      return div.innerHTML;
    }
    /**
     * Utility wait function
     * @param {number} ms - Milliseconds to wait
     * @returns {Promise<void>}
     * @private
     */
    wait(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
    /**
     * Cleans up tracked elements
     * @returns {void}
     */
    cleanup() {
      this.validatedElements.clear();
    }
    /**
     * Gets statistics about DOM operations
     * @returns {Object} Statistics object
     */
    getStats() {
      return {
        validatedElements: this.validatedElements.size,
        isDocumentReady: document.readyState === "complete"
      };
    }
  };
  var domSafetyManager = new DOMSafetyManager();

  // src/cacheManager.js
  var CacheManager = class {
    constructor() {
      this.memoryCache = /* @__PURE__ */ new Map();
      this.storagePrefix = "prompter_cache_";
      this.defaultTTLs = {
        templates: 5 * 60 * 1e3,
        // 5 minutes
        stats: 1 * 60 * 1e3,
        // 1 minute  
        membership: 10 * 60 * 1e3,
        // 10 minutes
        default: 5 * 60 * 1e3
        // 5 minutes
      };
    }
    /**
     * Gets cache key with user prefix for multi-user support
     * @param {string} key - Base cache key
     * @param {string} userId - User ID (optional)
     * @returns {string} Full cache key
     * @private
     */
    getCacheKey(key, userId = null) {
      const userPrefix = userId ? `${userId}_` : "";
      return `${this.storagePrefix}${userPrefix}${key}`;
    }
    /**
     * Gets default TTL for a cache type
     * @param {string} key - Cache key
     * @returns {number} TTL in milliseconds
     * @private
     */
    getDefaultTTL(key) {
      if (key.includes("templates"))
        return this.defaultTTLs.templates;
      if (key.includes("stats"))
        return this.defaultTTLs.stats;
      if (key.includes("membership"))
        return this.defaultTTLs.membership;
      return this.defaultTTLs.default;
    }
    /**
     * Retrieves data from cache with TTL validation
     * @param {string} key - Cache key
     * @param {string} userId - User ID (optional)
     * @param {number} customTTL - Custom TTL override (optional)
     * @returns {Promise<any|null>} Cached data or null if expired/missing
     */
    async get(key, userId = null, customTTL = null) {
      const cacheKey = this.getCacheKey(key, userId);
      try {
        const memoryCached = this.memoryCache.get(cacheKey);
        if (memoryCached && this.isValidEntry(memoryCached, customTTL)) {
          return memoryCached.data;
        }
        const result = await chrome.storage.local.get([cacheKey]);
        const storageCached = result[cacheKey];
        if (storageCached && this.isValidEntry(storageCached, customTTL)) {
          this.memoryCache.set(cacheKey, storageCached);
          return storageCached.data;
        }
        return null;
      } catch (error) {
        console.warn(`Cache get error for ${key}:`, error);
        return null;
      }
    }
    /**
     * Stores data in cache with TTL
     * @param {string} key - Cache key
     * @param {any} data - Data to cache
     * @param {string} userId - User ID (optional)
     * @param {number} customTTL - Custom TTL override (optional)
     * @param {string} lastModified - Server last-modified timestamp (optional)
     * @returns {Promise<void>}
     */
    async set(key, data, userId = null, customTTL = null, lastModified = null) {
      const cacheKey = this.getCacheKey(key, userId);
      const ttl = customTTL || this.getDefaultTTL(key);
      const entry = {
        data,
        timestamp: Date.now(),
        ttl,
        lastModified
      };
      try {
        this.memoryCache.set(cacheKey, entry);
        await chrome.storage.local.set({ [cacheKey]: entry });
      } catch (error) {
        console.warn(`Cache set error for ${key}:`, error);
      }
    }
    /**
     * Checks if cached data is fresh compared to server timestamp
     * @param {string} key - Cache key
     * @param {string} serverLastModified - Server's last-modified timestamp
     * @param {string} userId - User ID (optional)
     * @returns {Promise<boolean>} True if cache is fresh
     */
    async isFresh(key, serverLastModified, userId = null) {
      if (!serverLastModified)
        return false;
      const cacheKey = this.getCacheKey(key, userId);
      try {
        const memoryCached = this.memoryCache.get(cacheKey);
        if (memoryCached && memoryCached.lastModified) {
          const isFresh = memoryCached.lastModified >= serverLastModified;
          return isFresh;
        }
        const result = await chrome.storage.local.get([cacheKey]);
        const storageCached = result[cacheKey];
        if (storageCached && storageCached.lastModified) {
          const isFresh = storageCached.lastModified >= serverLastModified;
          return isFresh;
        }
        return false;
      } catch (error) {
        console.warn(`Cache freshness check error for ${key}:`, error);
        return false;
      }
    }
    /**
     * Invalidates cache entry
     * @param {string} key - Cache key
     * @param {string} userId - User ID (optional)
     * @returns {Promise<void>}
     */
    async invalidate(key, userId = null) {
      const cacheKey = this.getCacheKey(key, userId);
      try {
        this.memoryCache.delete(cacheKey);
        await chrome.storage.local.remove([cacheKey]);
      } catch (error) {
        console.warn(`Cache invalidation error for ${key}:`, error);
      }
    }
    /**
     * Invalidates all cache entries for a user
     * @param {string} userId - User ID
     * @returns {Promise<void>}
     */
    async invalidateUser(userId) {
      try {
        const allStorage = await chrome.storage.local.get(null);
        const userPrefix = `${this.storagePrefix}${userId}_`;
        const keysToRemove = Object.keys(allStorage).filter(
          (key) => key.startsWith(userPrefix)
        );
        if (keysToRemove.length > 0) {
          await chrome.storage.local.remove(keysToRemove);
        }
        for (const [key] of this.memoryCache) {
          if (key.startsWith(userPrefix)) {
            this.memoryCache.delete(key);
          }
        }
      } catch (error) {
        console.warn(`Cache user invalidation error for ${userId}:`, error);
      }
    }
    /**
     * Clears all expired entries
     * @returns {Promise<void>}
     */
    async cleanup() {
      try {
        const allStorage = await chrome.storage.local.get(null);
        const keysToRemove = [];
        for (const [key, entry] of Object.entries(allStorage)) {
          if (key.startsWith(this.storagePrefix) && !this.isValidEntry(entry)) {
            keysToRemove.push(key);
          }
        }
        if (keysToRemove.length > 0) {
          await chrome.storage.local.remove(keysToRemove);
        }
        for (const [key, entry] of this.memoryCache) {
          if (!this.isValidEntry(entry)) {
            this.memoryCache.delete(key);
          }
        }
      } catch (error) {
        console.warn("Cache cleanup error:", error);
      }
    }
    /**
     * Checks if cache entry is valid (not expired)
     * @param {CacheEntry} entry - Cache entry
     * @param {number} customTTL - Custom TTL override (optional)  
     * @returns {boolean} True if valid
     * @private
     */
    isValidEntry(entry, customTTL = null) {
      if (!entry || typeof entry !== "object")
        return false;
      const ttl = customTTL || entry.ttl || this.defaultTTLs.default;
      const age = Date.now() - entry.timestamp;
      return age < ttl;
    }
    /**
     * Gets cache statistics
     * @returns {Promise<Object>} Cache statistics
     */
    async getStats() {
      try {
        const allStorage = await chrome.storage.local.get(null);
        const cacheEntries = Object.entries(allStorage).filter(
          ([key]) => key.startsWith(this.storagePrefix)
        );
        const stats = {
          totalEntries: cacheEntries.length,
          memoryEntries: this.memoryCache.size,
          validEntries: 0,
          expiredEntries: 0,
          totalSize: 0
        };
        for (const [key, entry] of cacheEntries) {
          if (this.isValidEntry(entry)) {
            stats.validEntries++;
          } else {
            stats.expiredEntries++;
          }
          stats.totalSize += JSON.stringify(entry).length;
        }
        return stats;
      } catch (error) {
        console.warn("Cache stats error:", error);
        return { error: error.message };
      }
    }
    /**
     * Helper method for conditional GET requests with cache support
     * @param {string} url - API URL
     * @param {Object} options - Fetch options
     * @param {string} cacheKey - Cache key
     * @param {string} userId - User ID (optional)
     * @param {number} ttl - Custom TTL (optional)
     * @returns {Promise<{data: any, fromCache: boolean}>} Response data and cache status
     */
    async fetchWithCache(url, options = {}, cacheKey, userId = null, ttl = null) {
      try {
        const cached = await this.get(cacheKey, userId, ttl);
        if (cached) {
          return { data: cached, fromCache: true };
        }
        const cacheKeyFull = this.getCacheKey(cacheKey, userId);
        const result = await chrome.storage.local.get([cacheKeyFull]);
        const cachedEntry = result[cacheKeyFull];
        const headers = { ...options.headers };
        if (cachedEntry && cachedEntry.lastModified) {
          headers["If-Modified-Since"] = cachedEntry.lastModified;
        }
        const response = await fetch(url, { ...options, headers });
        if (response.status === 304 && cachedEntry) {
          await this.set(cacheKey, cachedEntry.data, userId, ttl, cachedEntry.lastModified);
          return { data: cachedEntry.data, fromCache: true };
        }
        if (!response.ok) {
          throw new Error(`API request failed: ${response.status}`);
        }
        const data = await response.json();
        const lastModified = response.headers.get("Last-Modified") || (/* @__PURE__ */ new Date()).toISOString();
        await this.set(cacheKey, data, userId, ttl, lastModified);
        return { data, fromCache: false };
      } catch (error) {
        console.warn(`Fetch with cache error for ${cacheKey}:`, error);
        const staleCache = await this.get(cacheKey, userId, Number.MAX_SAFE_INTEGER);
        if (staleCache) {
          return { data: staleCache, fromCache: true };
        }
        throw error;
      }
    }
  };
  var cacheManager = new CacheManager();
  if (typeof chrome !== "undefined" && chrome.alarms) {
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === "prompter-cache-cleanup") {
        cacheManager.cleanup();
      }
    });
    chrome.alarms.create("prompter-cache-cleanup", {
      delayInMinutes: 30,
      periodInMinutes: 30
    });
  }

  // src/content/modules/messageHandler.js
  var MessageHandler = class {
    constructor() {
      this.messageHandlers = /* @__PURE__ */ new Map();
      this.defaultTimeout = 1e4;
      this.defaultRetries = 3;
      this.pendingMessages = /* @__PURE__ */ new Set();
    }
    /**
     * Sends message with retry mechanism and timeout
     * @param {Object} message - Message to send
     * @param {Object} options - Send options
     * @param {number} options.timeout - Timeout in milliseconds
     * @param {number} options.retries - Number of retry attempts
     * @param {boolean} options.expectResponse - Whether to expect a response
     * @returns {Promise<any>} Response or null if no response expected
     */
    async sendMessage(message, options = {}) {
      const {
        timeout = this.defaultTimeout,
        retries = this.defaultRetries,
        expectResponse = true
      } = options;
      if (!this.validateMessage(message)) {
        throw new Error("Invalid message format");
      }
      const messageId = this.generateMessageId();
      this.pendingMessages.add(messageId);
      try {
        return await this.attemptSendMessage(message, { timeout, retries, expectResponse, messageId });
      } finally {
        this.pendingMessages.delete(messageId);
      }
    }
    /**
     * Attempts to send message with retries
     * @param {Object} message - Message to send
     * @param {Object} options - Send options with messageId
     * @returns {Promise<any>} Response
     * @private
     */
    async attemptSendMessage(message, options) {
      const { timeout, retries, expectResponse, messageId } = options;
      let lastError;
      for (let attempt = 0; attempt <= retries; attempt++) {
        try {
          const response = await this.sendSingleMessage(message, timeout, expectResponse);
          if (expectResponse && !response) {
            throw new Error("No response received");
          }
          return response;
        } catch (error) {
          lastError = error;
          if (this.isNonRetryableError(error)) {
            break;
          }
          if (attempt < retries) {
            const delay = Math.min(1e3 * Math.pow(2, attempt), 5e3);
            await this.wait(delay);
          }
        }
      }
      throw new Error(`Message failed after ${retries + 1} attempts: ${(lastError == null ? void 0 : lastError.message) || "Unknown error"}`);
    }
    /**
     * Sends a single message with timeout
     * @param {Object} message - Message to send
     * @param {number} timeout - Timeout in milliseconds
     * @param {boolean} expectResponse - Whether to expect a response
     * @returns {Promise<any>} Response
     * @private
     */
    async sendSingleMessage(message, timeout, expectResponse) {
      return new Promise((resolve, reject) => {
        var _a;
        if (!((_a = chrome == null ? void 0 : chrome.runtime) == null ? void 0 : _a.sendMessage)) {
          reject(new Error("Chrome runtime API not available"));
          return;
        }
        const timeoutId = setTimeout(() => {
          reject(new Error(`Message timeout after ${timeout}ms`));
        }, timeout);
        try {
          chrome.runtime.sendMessage(message, (response) => {
            clearTimeout(timeoutId);
            if (chrome.runtime.lastError) {
              const error = new Error(chrome.runtime.lastError.message);
              error.isRuntimeError = true;
              reject(error);
              return;
            }
            if (expectResponse) {
              if (response === void 0 || response === null) {
                reject(new Error("Received null/undefined response"));
                return;
              }
              if (response.error) {
                reject(new Error(response.error));
                return;
              }
            }
            resolve(response);
          });
        } catch (error) {
          clearTimeout(timeoutId);
          reject(error);
        }
      });
    }
    /**
     * Validates message format
     * @param {Object} message - Message to validate
     * @returns {boolean} True if valid
     * @private
     */
    validateMessage(message) {
      if (!message || typeof message !== "object") {
        return false;
      }
      if (!message.action || typeof message.action !== "string") {
        return false;
      }
      return true;
    }
    /**
     * Checks if error is non-retryable
     * @param {Error} error - Error to check
     * @returns {boolean} True if non-retryable
     * @private
     */
    isNonRetryableError(error) {
      const nonRetryableMessages = [
        "Extension context invalidated",
        "Could not establish connection",
        "The message port closed before a response was received",
        "Chrome runtime API not available"
      ];
      return nonRetryableMessages.some(
        (msg) => error.message && error.message.includes(msg)
      );
    }
    /**
     * Registers a message handler
     * @param {string} action - Action to handle
     * @param {Function} handler - Handler function
     * @returns {void}
     */
    registerHandler(action, handler) {
      if (typeof action !== "string" || typeof handler !== "function") {
        throw new Error("Action must be string and handler must be function");
      }
      this.messageHandlers.set(action, handler);
    }
    /**
     * Handles incoming messages
     * @param {Object} message - Received message
     * @param {Object} sender - Message sender
     * @param {Function} sendResponse - Response callback
     * @returns {boolean} True if response will be sent asynchronously
     */
    handleMessage(message, sender, sendResponse) {
      try {
        if (!this.validateMessage(message)) {
          sendResponse({ error: "Invalid message format" });
          return false;
        }
        const handler = this.messageHandlers.get(message.action);
        if (!handler) {
          sendResponse({ error: `Unknown action: ${message.action}` });
          return false;
        }
        const result = handler(message, sender);
        if (result instanceof Promise) {
          result.then((response) => {
            try {
              sendResponse(response || { success: true });
            } catch (e) {
            }
          }).catch((error) => {
            try {
              sendResponse({ error: error.message || "Handler error" });
            } catch (e) {
            }
          });
          return true;
        }
        sendResponse(result || { success: true });
        return false;
      } catch (error) {
        console.error("Message handler error:", error);
        try {
          sendResponse({ error: error.message || "Unknown error" });
        } catch (e) {
        }
        return false;
      }
    }
    /**
     * Sets up message listener
     * @returns {Function} Cleanup function
     */
    setupListener() {
      var _a;
      const boundHandler = this.handleMessage.bind(this);
      if ((_a = chrome == null ? void 0 : chrome.runtime) == null ? void 0 : _a.onMessage) {
        chrome.runtime.onMessage.addListener(boundHandler);
        return () => {
          try {
            chrome.runtime.onMessage.removeListener(boundHandler);
          } catch (error) {
          }
        };
      }
      return () => {
      };
    }
    /**
     * Generates unique message ID
     * @returns {string} Message ID
     * @private
     */
    generateMessageId() {
      return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    /**
     * Utility wait function
     * @param {number} ms - Milliseconds to wait
     * @returns {Promise<void>}
     * @private
     */
    wait(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
    /**
     * Gets statistics about message handling
     * @returns {Object} Statistics
     */
    getStats() {
      return {
        registeredHandlers: this.messageHandlers.size,
        pendingMessages: this.pendingMessages.size,
        handlerActions: Array.from(this.messageHandlers.keys())
      };
    }
    /**
     * Cleans up pending messages and handlers
     * @returns {void}
     */
    cleanup() {
      this.pendingMessages.clear();
      this.messageHandlers.clear();
    }
  };
  var BackgroundCommunicator = class {
    constructor(messageHandler2) {
      this.messageHandler = messageHandler2 || new MessageHandler();
      this.pendingFormatRequests = /* @__PURE__ */ new Map();
      this.lastTemplatesFetch = 0;
      this.templatesFetchCooldown = 5e3;
      this.cachedTemplates = null;
    }
    /**
     * Formats text using a template with dual-channel communication to avoid timeouts
     * @param {string} templateId - Template ID
     * @param {string} selectedText - Text to format
     * @returns {Promise<string>} Formatted text
     */
    async formatText(templateId, selectedText) {
      const requestId = this.generateRequestId();
      try {
        const directMessagePromise = this.setupDirectMessageListener(requestId);
        const callbackPromise = this.messageHandler.sendMessage({
          action: "formatWithTemplate",
          templateId,
          selectedText,
          requestId
        }, {
          timeout: 3e4,
          // Increased timeout
          retries: 1,
          // Reduced retries since we have direct messaging fallback
          expectResponse: true
        });
        const response = await Promise.race([
          callbackPromise.catch((error) => {
            console.warn("Callback failed, waiting for direct message:", error);
            return directMessagePromise;
          }),
          directMessagePromise
        ]);
        if (response.error) {
          throw new Error(response.error);
        }
        if (!response.formattedText) {
          throw new Error("No formatted text received");
        }
        return response.formattedText;
      } finally {
        this.pendingFormatRequests.delete(requestId);
      }
    }
    /**
     * Sets up a listener for direct messages from background script
     * @param {string} requestId - Request ID to match responses
     * @returns {Promise<Object>} Response from direct message
     * @private
     */
    setupDirectMessageListener(requestId) {
      return new Promise((resolve, reject) => {
        this.pendingFormatRequests.set(requestId, {
          resolve,
          reject,
          timeout: setTimeout(() => {
            this.pendingFormatRequests.delete(requestId);
            reject(new Error("Request timed out after 30 seconds"));
          }, 3e4)
        });
      });
    }
    /**
     * Handles direct messages from background script (formatComplete/formatError)
     * @param {Object} message - Message from background script
     * @returns {void}
     */
    handleDirectMessage(message) {
      const { action, requestId } = message;
      if (!requestId) {
        if (action === "formatComplete" || action === "formatError") {
          this.handleLegacyDirectMessage(message);
        }
        return;
      }
      const pendingRequest = this.pendingFormatRequests.get(requestId);
      if (!pendingRequest) {
        return;
      }
      clearTimeout(pendingRequest.timeout);
      this.pendingFormatRequests.delete(requestId);
      if (action === "formatComplete") {
        pendingRequest.resolve({ formattedText: message.formattedText });
      } else if (action === "formatError") {
        pendingRequest.reject(new Error(message.error));
      }
    }
    /**
     * Handles legacy direct messages without requestId (for backward compatibility)
     * @param {Object} message - Legacy message
     * @returns {void}
     * @private
     */
    handleLegacyDirectMessage(message) {
      const entries = Array.from(this.pendingFormatRequests.entries());
      if (entries.length === 0) {
        console.warn("Received legacy direct message but no pending requests");
        return;
      }
      const [requestId, pendingRequest] = entries[entries.length - 1];
      clearTimeout(pendingRequest.timeout);
      this.pendingFormatRequests.delete(requestId);
      if (message.action === "formatComplete") {
        pendingRequest.resolve({ formattedText: message.formattedText });
      } else if (message.action === "formatError") {
        pendingRequest.reject(new Error(message.error));
      }
    }
    /**
     * Generates unique request ID
     * @returns {string} Request ID
     * @private
     */
    generateRequestId() {
      return `fmt_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    }
    /**
     * Gets available templates with advanced caching and rate limiting
     * @param {boolean} forceRefresh - Force refresh even if within cooldown period
     * @returns {Promise<Array>} Templates array
     */
    async getTemplates(forceRefresh = false) {
      try {
        const now = Date.now();
        if (!forceRefresh && this.cachedTemplates && now - this.lastTemplatesFetch < this.templatesFetchCooldown) {
          return this.cachedTemplates;
        }
        this.lastTemplatesFetch = now;
        const response = await this.messageHandler.sendMessage({
          action: "GET_TEMPLATES"
        }, {
          timeout: 1e4,
          retries: 2
          // Reduced retries since background script has caching
        });
        if (!Array.isArray(response.templates)) {
          throw new Error("Invalid templates response");
        }
        this.cachedTemplates = response.templates;
        return response.templates;
      } catch (error) {
        if (this.cachedTemplates) {
          return this.cachedTemplates;
        }
        throw error;
      }
    }
    /**
     * Notifies about text selection
     * @param {string} text - Selected text
     * @param {boolean} isInInputField - Whether selection is in input field
     * @returns {Promise<void>}
     */
    async notifyTextSelection(text, isInInputField) {
      await this.messageHandler.sendMessage({
        action: "TEXT_SELECTED",
        text,
        isInInputField
      }, {
        expectResponse: false,
        retries: 1
      });
    }
  };
  var messageHandler = new MessageHandler();
  var backgroundCommunicator = new BackgroundCommunicator(messageHandler);

  // src/content/modules/textSelection.js
  var TextSelectionManager = class {
    constructor() {
      this.selectedText = "";
      this.targetElement = null;
      this.selectionRange = null;
      this.setupEventListeners();
    }
    /**
     * Sets up event listeners for text selection
     * @private
     */
    setupEventListeners() {
      document.addEventListener("mouseup", this.captureSelection.bind(this));
      document.addEventListener(
        "selectionchange",
        this.captureSelection.bind(this)
      );
      this.setupSiteSpecificListeners();
    }
    /**
     * Sets up site-specific event listeners
     * @private
     */
    setupSiteSpecificListeners() {
      if (window.location.hostname === "t3.chat" || window.location.hostname === "www.t3.chat") {
        setTimeout(() => {
          const body = document.querySelector("body");
          if (body) {
            body.addEventListener("mouseup", this.captureSelection.bind(this));
          }
        }, 1e3);
      }
    }
    /**
     * Captures the current text selection
     * @param {Event} [event] - The triggering event
     * @private
     */
    captureSelection(event) {
      try {
        const selectionInfo = getCurrentSelection();
        if (!selectionInfo) {
          this.clearSelection();
          return;
        }
        if (selectionInfo.element && !domSafetyManager.isValidElement(selectionInfo.element)) {
          console.warn("Invalid target element detected in selection");
          this.clearSelection();
          return;
        }
        this.selectedText = selectionInfo.text;
        this.targetElement = selectionInfo.element;
        this.selectionRange = selectionInfo.range;
        if (selectionInfo.isInInputField) {
          this.notifyBackgroundScript(selectionInfo);
        }
      } catch (error) {
        console.error("Error capturing selection:", error);
        this.clearSelection();
      }
    }
    /**
     * Notifies the background script about text selection
     * @param {SelectionInfo} selectionInfo - Selection information
     * @private
     */
    async notifyBackgroundScript(selectionInfo) {
      try {
        await backgroundCommunicator.notifyTextSelection(
          selectionInfo.text,
          true
        );
      } catch (error) {
        console.warn("Failed to notify background script:", error);
      }
    }
    /**
     * Clears the current selection data
     * @private
     */
    clearSelection() {
      this.selectedText = "";
      this.targetElement = null;
      this.selectionRange = null;
    }
    /**
     * Gets the current selection information
     * @returns {SelectionInfo|null} Current selection info or null if no selection
     * @public
     */
    getCurrentSelection() {
      if (!this.selectedText) {
        return null;
      }
      return {
        text: this.selectedText,
        element: this.targetElement,
        range: this.selectionRange,
        isInInputField: isTextInput(this.targetElement)
      };
    }
    /**
     * Validates if there's a valid text selection in an input field
     * @returns {boolean} True if there's a valid selection
     * @public
     */
    hasValidSelection() {
      const selection = this.getCurrentSelection();
      return Boolean(
        selection && selection.text.length > 0 && selection.element && selection.isInInputField
      );
    }
    /**
     * Gets the selected text
     * @returns {string} Currently selected text
     * @public
     */
    getSelectedText() {
      return this.selectedText;
    }
    /**
     * Gets the target element
     * @returns {HTMLElement|null} Element containing the selection
     * @public
     */
    getTargetElement() {
      return this.targetElement;
    }
    /**
     * Gets the selection range
     * @returns {Range|null} Selection range object
     * @public
     */
    getSelectionRange() {
      return this.selectionRange;
    }
    /**
     * Manually sets selection data (useful for testing or programmatic selection)
     * @param {string} text - Selected text
     * @param {HTMLElement} element - Target element
     * @param {Range} [range] - Selection range
     * @public
     */
    setSelection(text, element, range = null) {
      try {
        if (typeof text !== "string") {
          console.warn("Selection text must be a string");
          return;
        }
        if (element && !domSafetyManager.isValidElement(element)) {
          console.warn("Invalid element provided for selection");
          return;
        }
        this.selectedText = text;
        this.targetElement = element;
        this.selectionRange = range;
      } catch (error) {
        console.error("Error setting selection:", error);
        this.clearSelection();
      }
    }
  };
  var textSelectionManager = new TextSelectionManager();

  // src/content/modules/siteHandlers.js
  var SiteHandler = class {
    /**
     * @param {string} siteName - Name of the site this handler supports
     */
    constructor(siteName) {
      this.siteName = siteName;
    }
    /**
     * Replaces text in the target element
     * @param {HTMLElement} element - Target element
     * @param {string} newText - Text to insert
     * @param {TextReplacementOptions} [options] - Replacement options
     * @returns {Promise<ReplacementResult>} Replacement result
     * @abstract
     */
    async replaceText(element, newText, options = {}) {
      throw new Error(
        `replaceText must be implemented by ${this.constructor.name}`
      );
    }
    /**
     * Focuses the element and prepares for text replacement
     * @param {HTMLElement} element - Target element
     * @protected
     */
    async prepareElement(element) {
      try {
        if (!domSafetyManager.isValidElement(element)) {
          throw new Error("Invalid element provided for preparation");
        }
        if (!domSafetyManager.safeFocus(element)) {
          console.warn("Failed to focus element, continuing anyway");
        }
        await wait(TIMING.FOCUS_DELAY);
      } catch (error) {
        console.error("Element preparation failed:", error);
        throw error;
      }
    }
    /**
     * Triggers events to notify the page of changes
     * @param {HTMLElement} element - Target element
     * @param {string} newText - Inserted text
     * @protected
     */
    triggerChangeEvents(element, newText) {
      dispatchEvents(element, EVENTS.INPUT_EVENTS);
      if (element._valueTracker) {
        element._valueTracker.setValue("");
      }
    }
    /**
     * Creates a successful replacement result
     * @param {HTMLElement} element - Target element
     * @returns {ReplacementResult} Success result
     * @protected
     */
    createSuccessResult(element) {
      return {
        success: true,
        element
      };
    }
    /**
     * Creates a failed replacement result
     * @param {string} error - Error message
     * @returns {ReplacementResult} Error result
     * @protected
     */
    createErrorResult(error) {
      return {
        success: false,
        error
      };
    }
  };
  var DefaultHandler = class extends SiteHandler {
    constructor() {
      super("Default");
    }
    /**
     * @inheritdoc
     */
    async replaceText(element, newText, options = {}) {
      try {
        if (!domSafetyManager.isValidElement(element)) {
          throw new Error("Invalid element provided");
        }
        if (typeof newText !== "string") {
          throw new Error("New text must be a string");
        }
        await this.prepareElement(element);
        if (element.contentEditable === "true") {
          return await this.replaceInContentEditable(element, newText);
        } else {
          return await this.replaceInInputElement(element, newText);
        }
      } catch (error) {
        console.error(`Default replacement failed:`, error);
        return this.createErrorResult(error.message);
      }
    }
    /**
     * Replaces text in contenteditable elements
     * @param {HTMLElement} element - Contenteditable element
     * @param {string} newText - New text
     * @returns {Promise<ReplacementResult>} Replacement result
     * @private
     */
    async replaceInContentEditable(element, newText) {
      const selection = window.getSelection();
      if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        range.deleteContents();
        const lines = newText.split("\n");
        const fragment = document.createDocumentFragment();
        lines.forEach((line, index) => {
          if (line.length > 0) {
            fragment.appendChild(document.createTextNode(line));
          }
          if (index < lines.length - 1) {
            fragment.appendChild(document.createElement("br"));
          }
        });
        range.insertNode(fragment);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
      }
      this.triggerChangeEvents(element, newText);
      return this.createSuccessResult(element);
    }
    /**
     * Replaces text in input/textarea elements
     * @param {HTMLElement} element - Input element
     * @param {string} newText - New text
     * @returns {Promise<ReplacementResult>} Replacement result
     * @private
     */
    async replaceInInputElement(element, newText) {
      const start = element.selectionStart || 0;
      const end = element.selectionEnd || 0;
      const value = element.value || "";
      element.value = value.substring(0, start) + newText + value.substring(end);
      element.selectionStart = start;
      element.selectionEnd = start + newText.length;
      this.triggerChangeEvents(element, newText);
      return this.createSuccessResult(element);
    }
  };
  var PerplexityHandler = class extends SiteHandler {
    constructor() {
      super("Perplexity");
    }
    /**
     * @inheritdoc
     */
    async replaceText(element, newText, options = {}) {
      try {
        await this.prepareElement(element);
        if (element.contentEditable === "true") {
          if (await this.tryExecCommand(element, newText)) {
            return this.createSuccessResult(element);
          }
        }
        const defaultHandler = new DefaultHandler();
        return await defaultHandler.replaceText(element, newText, options);
      } catch (error) {
        console.error(`Perplexity replacement failed:`, error);
        return this.createErrorResult(error.message);
      }
    }
    /**
     * Attempts to use execCommand for text replacement
     * @param {HTMLElement} element - Target element
     * @param {string} newText - New text
     * @returns {Promise<boolean>} True if successful
     * @private
     */
    async tryExecCommand(element, newText) {
      try {
        document.execCommand("selectAll", false, null);
        document.execCommand("delete", false, null);
        document.execCommand("insertText", false, newText);
        dispatchReactInputEvent(element, newText);
        return true;
      } catch (error) {
        console.warn("execCommand failed for Perplexity:", error);
        return false;
      }
    }
  };
  var ChatGPTHandler = class extends SiteHandler {
    constructor() {
      super("ChatGPT");
    }
    /**
     * @inheritdoc
     */
    async replaceText(element, newText, options = {}) {
      try {
        await this.prepareElement(element);
        if (element.contentEditable === "true") {
          return await this.replaceInChatGPTContentEditable(element, newText);
        } else {
          const defaultHandler = new DefaultHandler();
          return await defaultHandler.replaceText(element, newText, options);
        }
      } catch (error) {
        console.error(`ChatGPT replacement failed:`, error);
        return this.createErrorResult(error.message);
      }
    }
    /**
     * Replaces text in ChatGPT's contenteditable elements
     * @param {HTMLElement} element - Target element
     * @param {string} newText - New text
     * @returns {Promise<ReplacementResult>} Replacement result
     * @private
     */
    async replaceInChatGPTContentEditable(element, newText) {
      try {
        const selection2 = window.getSelection();
        if (selection2.rangeCount > 0) {
          const range2 = document.createRange();
          range2.selectNodeContents(element);
          selection2.removeAllRanges();
          selection2.addRange(range2);
          document.execCommand("insertText", false, newText);
          this.triggerReactEvents(element, newText);
          return this.createSuccessResult(element);
        }
      } catch (error) {
        console.warn("ChatGPT execCommand failed:", error);
      }
      element.innerHTML = "";
      element.textContent = newText;
      const range = document.createRange();
      const selection = window.getSelection();
      range.selectNodeContents(element);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);
      this.triggerReactEvents(element, newText);
      return this.createSuccessResult(element);
    }
    /**
     * Triggers React-specific events for ChatGPT
     * @param {HTMLElement} element - Target element
     * @param {string} newText - New text
     * @private
     */
    triggerReactEvents(element, newText) {
      dispatchReactInputEvent(element, newText);
      element.dispatchEvent(
        new CompositionEvent("compositionstart", { bubbles: true })
      );
      element.dispatchEvent(
        new CompositionEvent("compositionend", { bubbles: true, data: newText })
      );
      this.triggerChangeEvents(element, newText);
    }
  };
  var ClaudeHandler = class extends SiteHandler {
    constructor() {
      super("Claude");
    }
    /**
     * @inheritdoc
     */
    async replaceText(element, newText, options = {}) {
      try {
        await this.prepareElement(element);
        if (element.contentEditable === "true") {
          return await this.replaceInClaudeContentEditable(element, newText);
        } else {
          const defaultHandler = new DefaultHandler();
          return await defaultHandler.replaceText(element, newText, options);
        }
      } catch (error) {
        console.error(`Claude replacement failed:`, error);
        return this.createErrorResult(error.message);
      }
    }
    /**
     * Replaces text in Claude's contenteditable elements
     * @param {HTMLElement} element - Target element
     * @param {string} newText - New text
     * @returns {Promise<ReplacementResult>} Replacement result
     * @private
     */
    async replaceInClaudeContentEditable(element, newText) {
      element.innerHTML = "";
      const lines = newText.split("\n");
      const fragment = document.createDocumentFragment();
      lines.forEach((line, index) => {
        const div = document.createElement("div");
        if (line.length > 0) {
          div.textContent = line;
        } else {
          div.innerHTML = "<br>";
        }
        fragment.appendChild(div);
      });
      element.appendChild(fragment);
      const range = document.createRange();
      const selection = window.getSelection();
      range.selectNodeContents(element);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);
      this.triggerChangeEvents(element, newText);
      return this.createSuccessResult(element);
    }
  };
  var T3ChatHandler = class extends SiteHandler {
    constructor() {
      super("T3Chat");
    }
    /**
     * @inheritdoc
     */
    async replaceText(element, newText, options = {}) {
      try {
        await this.prepareElement(element);
        if (element.tagName.toLowerCase() === "textarea" || element.tagName.toLowerCase() === "input") {
          return await this.replaceInT3ChatInput(element, newText);
        } else {
          const defaultHandler = new DefaultHandler();
          return await defaultHandler.replaceText(element, newText, options);
        }
      } catch (error) {
        console.error(`T3Chat replacement failed:`, error);
        return this.createErrorResult(error.message);
      }
    }
    /**
     * Replaces text in T3Chat input elements with special event handling
     * @param {HTMLElement} element - Target element
     * @param {string} newText - New text
     * @returns {Promise<ReplacementResult>} Replacement result
     * @private
     */
    async replaceInT3ChatInput(element, newText) {
      const start = element.selectionStart || 0;
      const end = element.selectionEnd || 0;
      const value = element.value || "";
      element.value = value.substring(0, start) + newText + value.substring(end);
      element.selectionStart = start;
      element.selectionEnd = start + newText.length;
      this.preventEventConflicts(element);
      await wait(TIMING.REACT_EVENT_DELAY);
      dispatchEvents(element, ["input", "change"]);
      return this.createSuccessResult(element);
    }
    /**
     * Prevents event conflicts for T3Chat
     * @param {HTMLElement} element - Target element
     * @private
     */
    preventEventConflicts(element) {
      const stopEvent = (e) => {
        e.stopPropagation();
        e.preventDefault();
      };
      element.addEventListener("paste", stopEvent, { once: true, capture: true });
      element.addEventListener("input", stopEvent, { once: true, capture: true });
    }
  };
  var GeminiHandler = class extends SiteHandler {
    constructor() {
      super("Gemini");
    }
    /**
     * @inheritdoc
     */
    async replaceText(element, newText, options = {}) {
      try {
        await this.prepareElement(element);
        if (element.contentEditable === "true") {
          return await this.replaceInGeminiContentEditable(element, newText);
        } else {
          const defaultHandler = new DefaultHandler();
          return await defaultHandler.replaceText(element, newText, options);
        }
      } catch (error) {
        console.error(`Gemini replacement failed:`, error);
        return this.createErrorResult(error.message);
      }
    }
    /**
     * Replaces text in Gemini's contenteditable elements
     * @param {HTMLElement} element - Target element
     * @param {string} newText - New text
     * @returns {Promise<ReplacementResult>} Replacement result
     * @private
     */
    async replaceInGeminiContentEditable(element, newText) {
      try {
        document.execCommand("selectAll", false, null);
        document.execCommand("insertText", false, newText);
        this.triggerChangeEvents(element, newText);
        return this.createSuccessResult(element);
      } catch (error) {
        console.warn("Gemini execCommand failed, using fallback");
        const defaultHandler = new DefaultHandler();
        return await defaultHandler.replaceText(element, newText);
      }
    }
  };
  var CursorHandler = class extends SiteHandler {
    constructor() {
      super("Cursor");
    }
    /**
     * @inheritdoc
     */
    async replaceText(element, newText, options = {}) {
      try {
        await this.prepareElement(element);
        if (element.contentEditable === "true") {
          return await this.replaceInCursorContentEditable(element, newText);
        } else if (element.tagName.toLowerCase() === "textarea") {
          return await this.replaceInCursorTextarea(element, newText);
        } else {
          const defaultHandler = new DefaultHandler();
          return await defaultHandler.replaceText(element, newText, options);
        }
      } catch (error) {
        console.error(`Cursor replacement failed:`, error);
        return this.createErrorResult(error.message);
      }
    }
    /**
     * Replaces text in Cursor's contenteditable elements
     * @param {HTMLElement} element - Target element
     * @param {string} newText - New text
     * @returns {Promise<ReplacementResult>} Replacement result
     * @private
     */
    async replaceInCursorContentEditable(element, newText) {
      try {
        const selection2 = window.getSelection();
        if (selection2.rangeCount > 0) {
          const range2 = document.createRange();
          range2.selectNodeContents(element);
          selection2.removeAllRanges();
          selection2.addRange(range2);
          document.execCommand("insertText", false, newText);
          this.triggerCursorEvents(element, newText);
          return this.createSuccessResult(element);
        }
      } catch (error) {
        console.warn("Cursor execCommand failed:", error);
      }
      element.innerHTML = "";
      element.textContent = newText;
      const range = document.createRange();
      const selection = window.getSelection();
      range.selectNodeContents(element);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);
      this.triggerCursorEvents(element, newText);
      return this.createSuccessResult(element);
    }
    /**
     * Replaces text in Cursor's textarea elements
     * @param {HTMLElement} element - Target element
     * @param {string} newText - New text
     * @returns {Promise<ReplacementResult>} Replacement result
     * @private
     */
    async replaceInCursorTextarea(element, newText) {
      const start = element.selectionStart || 0;
      const end = element.selectionEnd || 0;
      const value = element.value || "";
      element.value = value.substring(0, start) + newText + value.substring(end);
      element.selectionStart = start;
      element.selectionEnd = start + newText.length;
      this.triggerCursorEvents(element, newText);
      return this.createSuccessResult(element);
    }
    /**
     * Triggers events specific to Cursor's interface
     * @param {HTMLElement} element - Target element
     * @param {string} newText - New text
     * @private
     */
    triggerCursorEvents(element, newText) {
      dispatchEvents(element, ["input", "change"]);
      dispatchReactInputEvent(element, newText);
      element.dispatchEvent(new Event("blur", { bubbles: true }));
      element.dispatchEvent(new Event("focus", { bubbles: true }));
      element.dispatchEvent(new CustomEvent("cursor-text-change", {
        bubbles: true,
        detail: { text: newText }
      }));
    }
  };
  var SiteHandlerFactory = class {
    /**
     * Creates the appropriate handler based on the current site
     * @returns {SiteHandler} Site-specific handler instance
     * @static
     */
    static createHandler() {
      const siteDetection = detectCurrentSite();
      if (siteDetection.isPerplexity) {
        return new PerplexityHandler();
      } else if (siteDetection.isChatGPT) {
        return new ChatGPTHandler();
      } else if (siteDetection.isClaude) {
        return new ClaudeHandler();
      } else if (siteDetection.isT3Chat) {
        return new T3ChatHandler();
      } else if (siteDetection.isGemini) {
        return new GeminiHandler();
      } else if (siteDetection.isCursor) {
        return new CursorHandler();
      } else {
        return new DefaultHandler();
      }
    }
    /**
     * Gets the name of the current site handler
     * @returns {string} Handler name
     * @static
     */
    static getCurrentHandlerName() {
      return this.createHandler().siteName;
    }
  };

  // src/content/modules/errorHandler.js
  var ErrorHandler = class {
    constructor() {
      this.errorCounts = /* @__PURE__ */ new Map();
      this.errorHistory = [];
      this.maxHistorySize = 100;
      this.errorListeners = /* @__PURE__ */ new Set();
      this.setupGlobalErrorHandling();
    }
    /**
     * Sets up global error handling
     * @private
     */
    setupGlobalErrorHandling() {
      window.addEventListener("unhandledrejection", (event) => {
        this.handleError(event.reason, "unhandledRejection", {
          promise: event.promise,
          reason: event.reason
        });
      });
      window.addEventListener("error", (event) => {
        this.handleError(event.error, "globalError", {
          message: event.message,
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno
        });
      });
    }
    /**
     * Handles an error with context and recovery attempts
     * @param {Error|string} error - Error to handle
     * @param {string} context - Context where error occurred
     * @param {Object} metadata - Additional error metadata
     * @returns {void}
     */
    handleError(error, context, metadata = {}) {
      const errorObj = error instanceof Error ? error : new Error(String(error));
      const errorKey = `${context}:${errorObj.message}`;
      const count = (this.errorCounts.get(errorKey) || 0) + 1;
      this.errorCounts.set(errorKey, count);
      this.addToHistory(errorObj, context, metadata);
      console.error(`[${context}] Error occurred:`, {
        error: errorObj,
        context,
        count,
        metadata,
        stack: errorObj.stack
      });
      this.notifyListeners(errorObj, context, metadata);
      this.attemptRecovery(errorObj, context, metadata);
    }
    /**
     * Wraps a function with error handling
     * @param {Function} fn - Function to wrap
     * @param {string} context - Context for error reporting
     * @param {Object} options - Wrap options
     * @returns {Function} Wrapped function
     */
    wrapFunction(fn, context, options = {}) {
      const {
        fallback = null,
        retries = 0,
        timeout = null,
        suppressErrors = false
      } = options;
      return async (...args) => {
        let lastError;
        for (let attempt = 0; attempt <= retries; attempt++) {
          try {
            if (timeout) {
              return await this.withTimeout(fn.apply(this, args), timeout);
            } else {
              return await fn.apply(this, args);
            }
          } catch (error) {
            lastError = error;
            if (!suppressErrors) {
              this.handleError(error, `${context}:attempt${attempt + 1}`, {
                attempt: attempt + 1,
                maxRetries: retries + 1,
                args: args.map((arg) => typeof arg)
              });
            }
            if (attempt < retries) {
              await this.wait(Math.min(1e3 * Math.pow(2, attempt), 5e3));
            }
          }
        }
        if (fallback && typeof fallback === "function") {
          try {
            return await fallback(...args);
          } catch (fallbackError) {
            this.handleError(fallbackError, `${context}:fallback`, {
              originalError: lastError == null ? void 0 : lastError.message,
              fallbackError: fallbackError == null ? void 0 : fallbackError.message
            });
          }
        }
        throw lastError;
      };
    }
    /**
     * Wraps a promise with timeout
     * @param {Promise} promise - Promise to wrap
     * @param {number} timeout - Timeout in milliseconds
     * @returns {Promise} Promise with timeout
     */
    withTimeout(promise, timeout) {
      return Promise.race([
        promise,
        new Promise((_, reject) => {
          setTimeout(() => reject(new Error(`Operation timed out after ${timeout}ms`)), timeout);
        })
      ]);
    }
    /**
     * Adds error to history
     * @param {Error} error - Error object
     * @param {string} context - Error context
     * @param {Object} metadata - Error metadata
     * @private
     */
    addToHistory(error, context, metadata) {
      this.errorHistory.push({
        timestamp: Date.now(),
        error: {
          message: error.message,
          name: error.name,
          stack: error.stack
        },
        context,
        metadata
      });
      if (this.errorHistory.length > this.maxHistorySize) {
        this.errorHistory.shift();
      }
    }
    /**
     * Notifies error listeners
     * @param {Error} error - Error object
     * @param {string} context - Error context
     * @param {Object} metadata - Error metadata
     * @private
     */
    notifyListeners(error, context, metadata) {
      this.errorListeners.forEach((listener) => {
        try {
          listener(error, context, metadata);
        } catch (listenerError) {
          console.error("Error listener failed:", listenerError);
        }
      });
    }
    /**
     * Attempts recovery based on error type and context
     * @param {Error} error - Error object
     * @param {string} context - Error context
     * @param {Object} metadata - Error metadata
     * @private
     */
    attemptRecovery(error, context, metadata) {
      try {
        if (context.includes("DOM") || error.message.includes("not found")) {
          this.attemptDOMRecovery(error, context);
        }
        if (context.includes("message") || error.message.includes("runtime")) {
          this.attemptMessageRecovery(error, context);
        }
        if (context.includes("modal")) {
          this.attemptModalRecovery(error, context);
        }
      } catch (recoveryError) {
        console.error("Recovery attempt failed:", recoveryError);
      }
    }
    /**
     * Attempts DOM-related recovery
     * @param {Error} error - Error object
     * @param {string} context - Error context
     * @private
     */
    attemptDOMRecovery(error, context) {
      if (document.readyState !== "complete") {
        document.addEventListener("DOMContentLoaded", () => {
        }, { once: true });
      }
      this.cleanupOrphanedElements();
    }
    /**
     * Attempts message passing recovery
     * @param {Error} error - Error object
     * @param {string} context - Error context
     * @private
     */
    attemptMessageRecovery(error, context) {
      var _a;
      if (!((_a = chrome == null ? void 0 : chrome.runtime) == null ? void 0 : _a.id)) {
        console.warn("Chrome runtime not available, extension may be reloading");
        return;
      }
      this.clearPendingMessages();
    }
    /**
     * Attempts modal recovery
     * @param {Error} error - Error object
     * @param {string} context - Error context
     * @private
     */
    attemptModalRecovery(error, context) {
      const modals = document.querySelectorAll(".prompter-modal-overlay");
      modals.forEach((modal) => {
        try {
          if (modal.parentNode) {
            modal.parentNode.removeChild(modal);
          }
        } catch (cleanupError) {
          console.warn("Failed to cleanup modal:", cleanupError);
        }
      });
    }
    /**
     * Cleans up orphaned DOM elements
     * @private
     */
    cleanupOrphanedElements() {
      try {
        const orphanedElements = document.querySelectorAll('[class*="prompter-"]:not([data-prompter-managed])');
        let cleanedCount = 0;
        orphanedElements.forEach((element) => {
          try {
            if (!element.isConnected || !element.parentNode) {
              element.remove();
              cleanedCount++;
            }
          } catch (e) {
          }
        });
      } catch (error) {
        console.warn("Element cleanup failed:", error);
      }
    }
    /**
     * Clears pending messages
     * @private
     */
    clearPendingMessages() {
    }
    /**
     * Adds an error listener
     * @param {Function} listener - Error listener function
     * @returns {Function} Cleanup function
     */
    addErrorListener(listener) {
      this.errorListeners.add(listener);
      return () => this.errorListeners.delete(listener);
    }
    /**
     * Gets error statistics
     * @returns {Object} Error statistics
     */
    getErrorStats() {
      const recentErrors = this.errorHistory.filter(
        (entry) => Date.now() - entry.timestamp < 6e4
        // Last minute
      );
      return {
        totalErrors: this.errorHistory.length,
        recentErrors: recentErrors.length,
        errorCounts: Object.fromEntries(this.errorCounts),
        mostCommonErrors: this.getMostCommonErrors(5)
      };
    }
    /**
     * Gets most common errors
     * @param {number} limit - Number of errors to return
     * @returns {Array} Most common errors
     * @private
     */
    getMostCommonErrors(limit = 5) {
      return Array.from(this.errorCounts.entries()).sort((a, b) => b[1] - a[1]).slice(0, limit).map(([error, count]) => ({ error, count }));
    }
    /**
     * Clears error history and counts
     * @returns {void}
     */
    clearHistory() {
      this.errorHistory = [];
      this.errorCounts.clear();
    }
    /**
     * Creates a safe execution context
     * @param {Function} fn - Function to execute safely
     * @param {string} context - Execution context
     * @param {*} fallbackValue - Value to return on error
     * @returns {*} Function result or fallback value
     */
    safeExecute(fn, context, fallbackValue = null) {
      try {
        return fn();
      } catch (error) {
        this.handleError(error, context);
        return fallbackValue;
      }
    }
    /**
     * Utility wait function
     * @param {number} ms - Milliseconds to wait
     * @returns {Promise<void>}
     * @private
     */
    wait(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
  };
  var ERROR_MESSAGES = {
    DOM_NOT_FOUND: "The page element could not be found. Please try refreshing the page.",
    DOM_NOT_ACCESSIBLE: "The page element is not accessible. Please try selecting text in a different area.",
    NETWORK_ERROR: "Connection error. Please check your internet connection and try again.",
    AUTHENTICATION_ERROR: "Authentication failed. Please sign in again through the extension popup.",
    TEMPLATE_ERROR: "Template processing failed. Please try selecting a different template.",
    PERMISSION_ERROR: "Permission denied. Please check extension permissions.",
    TIMEOUT_ERROR: "The operation took too long. Please try again.",
    UNKNOWN_ERROR: "An unexpected error occurred. Please try again or contact support."
  };
  function getUserFriendlyErrorMessage(error) {
    var _a;
    const message = ((_a = error == null ? void 0 : error.message) == null ? void 0 : _a.toLowerCase()) || "";
    if (message.includes("not found") || message.includes("null")) {
      return ERROR_MESSAGES.DOM_NOT_FOUND;
    }
    if (message.includes("not accessible") || message.includes("disabled")) {
      return ERROR_MESSAGES.DOM_NOT_ACCESSIBLE;
    }
    if (message.includes("network") || message.includes("fetch")) {
      return ERROR_MESSAGES.NETWORK_ERROR;
    }
    if (message.includes("auth") || message.includes("token")) {
      return ERROR_MESSAGES.AUTHENTICATION_ERROR;
    }
    if (message.includes("template")) {
      return ERROR_MESSAGES.TEMPLATE_ERROR;
    }
    if (message.includes("permission")) {
      return ERROR_MESSAGES.PERMISSION_ERROR;
    }
    if (message.includes("timeout")) {
      return ERROR_MESSAGES.TIMEOUT_ERROR;
    }
    return ERROR_MESSAGES.UNKNOWN_ERROR;
  }
  var errorHandler = new ErrorHandler();

  // src/content/modules/visualFeedback.js
  var VisualFeedbackManager = class {
    constructor() {
      this.stylesAdded = false;
    }
    /**
     * Shows a notification to the user
     * @param {string} message - Notification message
     * @param {'error'|'success'|'info'} type - Notification type
     * @param {number} [duration] - Display duration in milliseconds
     * @example
     * ```javascript
     * feedbackManager.showNotification('Success!', 'success');
     * ```
     */
    showNotification(message, type, duration = TIMING.NOTIFICATION_TIMEOUT) {
      try {
        const notification = this.createNotificationElement(message, type);
        if (!domSafetyManager.isValidElement(notification)) {
          throw new Error("Failed to create notification element");
        }
        if (!document.body) {
          throw new Error("Document body not available");
        }
        document.body.appendChild(notification);
        setTimeout(() => {
          if (domSafetyManager.isValidElement(notification)) {
            domSafetyManager.safeRemoveElement(notification);
          }
        }, duration);
      } catch (error) {
        errorHandler.handleError(error, "visualFeedback.showNotification", {
          message,
          type,
          duration
        });
        console.log(`[${type.toUpperCase()}] ${message}`);
      }
    }
    /**
     * Creates a notification DOM element
     * @param {string} message - Notification message
     * @param {'error'|'success'|'info'} type - Notification type
     * @returns {HTMLElement} Notification element
     * @private
     */
    createNotificationElement(message, type) {
      const notification = document.createElement("div");
      notification.textContent = message;
      const { bgColor, borderColor } = this.getNotificationColors(type);
      notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 20px;
      background-color: ${bgColor};
      color: ${COLORS.WHITE};
      border: 1px solid ${borderColor};
      border-radius: calc(1.4rem - 6px);
      box-shadow: 0px 2px 3px 0px hsl(0 0% 0% / 0.16), 0px 1px 2px -1px hsl(0 0% 0% / 0.16);
      z-index: ${Z_INDEX.NOTIFICATION};
      font-family: 'Plus Jakarta Sans', sans-serif;
      font-size: 14px;
      font-weight: 500;
      letter-spacing: -0.025em;
      animation: prompter-notification-enter 0.2s ease-out;
    `;
      return notification;
    }
    /**
     * Gets colors for notification based on type
     * @param {'error'|'success'|'info'} type - Notification type
     * @returns {{bgColor: string, borderColor: string}} Color configuration
     * @private
     */
    getNotificationColors(type) {
      switch (type) {
        case NOTIFICATION_TYPES.ERROR:
          return { bgColor: COLORS.ERROR, borderColor: COLORS.ERROR };
        case NOTIFICATION_TYPES.SUCCESS:
          return { bgColor: COLORS.SUCCESS, borderColor: COLORS.SUCCESS };
        default:
          return { bgColor: COLORS.INFO, borderColor: COLORS.INFO };
      }
    }
    /**
     * Shows visual feedback when text is replaced
     * @param {HTMLElement} element - Element where text was replaced
     * @returns {Promise<void>} Promise that resolves when animation completes
     * @example
     * ```javascript
     * await feedbackManager.showTextReplacementFeedback(inputElement);
     * ```
     */
    async showTextReplacementFeedback(element) {
      if (!element) {
        console.warn("No element provided for replacement feedback");
        return;
      }
      this.ensureTransitionStyles();
      const overlay = this.createReplacementOverlay(element);
      const originalStyles = this.applyHighlightEffect(element);
      document.body.appendChild(overlay);
      requestAnimationFrame(() => {
        overlay.style.animation = `prompter-replacement-pulse ${TIMING.ANIMATION_DURATION}ms ease-out`;
      });
      this.showNotification(
        "\u2728 Text formatted successfully!",
        NOTIFICATION_TYPES.SUCCESS
      );
      await this.cleanupReplacementFeedback(element, overlay, originalStyles);
    }
    /**
     * Creates the replacement overlay element
     * @param {HTMLElement} element - Target element
     * @returns {HTMLElement} Overlay element
     * @private
     */
    createReplacementOverlay(element) {
      const overlay = document.createElement("div");
      overlay.className = CSS_CLASSES.REPLACEMENT_OVERLAY;
      const bounds = getElementBounds(element);
      const borderRadius = window.getComputedStyle(element).borderRadius || "4px";
      overlay.style.cssText = `
      position: absolute;
      top: ${bounds.top}px;
      left: ${bounds.left}px;
      width: ${bounds.width}px;
      height: ${bounds.height}px;
      pointer-events: none;
      z-index: ${Z_INDEX.REPLACEMENT_OVERLAY};
      border-radius: ${borderRadius};
    `;
      return overlay;
    }
    /**
     * Applies highlight effect to the element
     * @param {HTMLElement} element - Target element
     * @returns {Object} Original styles for restoration
     * @private
     */
    applyHighlightEffect(element) {
      const originalStyles = {
        transition: element.style.transition,
        boxShadow: element.style.boxShadow,
        border: element.style.border
      };
      element.style.transition = "all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94)";
      element.style.boxShadow = `0 0 0 2px ${COLORS.PURPLE_GLOW}, 0 0 20px rgba(139, 92, 246, 0.3)`;
      element.style.border = "1px solid rgba(139, 92, 246, 0.6)";
      return originalStyles;
    }
    /**
     * Cleans up replacement feedback effects
     * @param {HTMLElement} element - Target element
     * @param {HTMLElement} overlay - Overlay element
     * @param {Object} originalStyles - Original element styles
     * @returns {Promise<void>} Promise that resolves when cleanup is complete
     * @private
     */
    async cleanupReplacementFeedback(element, overlay, originalStyles) {
      return new Promise((resolve) => {
        setTimeout(() => {
          element.style.transition = originalStyles.transition;
          element.style.boxShadow = originalStyles.boxShadow;
          element.style.border = originalStyles.border;
          if (overlay.parentNode) {
            overlay.parentNode.removeChild(overlay);
          }
          resolve();
        }, TIMING.ANIMATION_DURATION);
      });
    }
    /**
     * Ensures transition styles are added to the page
     * @private
     */
    ensureTransitionStyles() {
      if (this.stylesAdded)
        return;
      const styleId = CSS_CLASSES.TRANSITION_STYLES;
      if (document.getElementById(styleId)) {
        this.stylesAdded = true;
        return;
      }
      const style = document.createElement("style");
      style.id = styleId;
      style.textContent = this.getTransitionCSS();
      document.head.appendChild(style);
      this.stylesAdded = true;
    }
    /**
     * Gets the CSS for transitions and animations
     * @returns {string} CSS content
     * @private
     */
    getTransitionCSS() {
      return `
      .${CSS_CLASSES.REPLACEMENT_OVERLAY} {
        background: linear-gradient(45deg, 
          rgba(139, 92, 246, 0.15) 0%, 
          rgba(139, 92, 246, 0.25) 50%, 
          rgba(139, 92, 246, 0.15) 100%);
        border: 1px solid rgba(139, 92, 246, 0.4);
      }
      
      @keyframes prompter-replacement-pulse {
        0% {
          transform: scale(1);
          opacity: 0;
          background: rgba(139, 92, 246, 0.3);
        }
        25% {
          transform: scale(1.02);
          opacity: 1;
          background: rgba(139, 92, 246, 0.2);
        }
        75% {
          transform: scale(1.01);
          opacity: 0.8;
          background: rgba(139, 92, 246, 0.1);
        }
        100% {
          transform: scale(1);
          opacity: 0;
          background: rgba(139, 92, 246, 0.05);
        }
      }
      
      @keyframes prompter-notification-enter {
        from {
          opacity: 0;
          transform: translateX(100px);
        }
        to {
          opacity: 1;
          transform: translateX(0);
        }
      }
      
      @keyframes prompter-glow-fade {
        0% {
          box-shadow: 0 0 0 2px ${COLORS.PURPLE_GLOW_STRONG}, 0 0 25px ${COLORS.PURPLE_GLOW};
        }
        100% {
          box-shadow: 0 0 0 0px rgba(139, 92, 246, 0), 0 0 0px rgba(139, 92, 246, 0);
        }
      }
    `;
    }
    /**
     * Shows a loading notification
     * @param {string} [message='Formatting text...'] - Loading message
     */
    showLoading(message = "Formatting text...") {
      this.showNotification(message, NOTIFICATION_TYPES.INFO);
    }
    /**
     * Shows an error notification
     * @param {string|Error} message - Error message or Error object
     */
    showError(message) {
      const errorMessage = message instanceof Error ? getUserFriendlyErrorMessage(message) : message;
      this.showNotification(errorMessage, NOTIFICATION_TYPES.ERROR);
    }
    /**
     * Shows user-friendly error for technical errors
     * @param {Error} error - Error object
     * @param {string} context - Error context
     * @param {number} [duration] - Display duration
     */
    showUserFriendlyError(error, context, duration) {
      errorHandler.handleError(error, context);
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      this.showNotification(friendlyMessage, NOTIFICATION_TYPES.ERROR, duration);
    }
    /**
     * Shows a success notification
     * @param {string} message - Success message
     */
    showSuccess(message) {
      this.showNotification(message, NOTIFICATION_TYPES.SUCCESS);
    }
  };
  var visualFeedbackManager = new VisualFeedbackManager();

  // src/content/modules/textReplacement.js
  var TextReplacementManager = class {
    constructor() {
      this.siteHandler = SiteHandlerFactory.createHandler();
    }
    /**
     * Replaces selected text with formatted content
     * @param {string} newText - The formatted text to insert
     * @param {TextReplacementOptions} [options={}] - Replacement options
     * @returns {Promise<ReplacementResult>} Replacement result
     * @example
     * ```javascript
     * const result = await textReplacer.replaceSelectedText('Formatted JSON content');
     * if (result.success) {
     *   console.log('Text replaced successfully');
     * }
     * ```
     */
    async replaceSelectedText(newText, options = {}) {
      const {
        targetElement = null,
        showFeedback = true,
        useStoredRange = false
      } = options;
      try {
        const element = await this.findTargetElement(
          targetElement,
          useStoredRange
        );
        if (!element) {
          return {
            success: false,
            error: "No editable element found"
          };
        }
        const result = await this.siteHandler.replaceText(
          element,
          newText,
          options
        );
        if (result.success && showFeedback) {
          await visualFeedbackManager.showTextReplacementFeedback(element);
        }
        return result;
      } catch (error) {
        console.error("Text replacement failed:", error);
        return {
          success: false,
          error: error.message || "Unknown error occurred"
        };
      }
    }
    /**
     * Finds the target element for text replacement
     * @param {HTMLElement|null} targetElement - Optional target element override
     * @param {boolean} useStoredRange - Whether to use stored selection range
     * @returns {Promise<HTMLElement|null>} Target element or null if not found
     * @private
     */
    async findTargetElement(targetElement, useStoredRange) {
      try {
        if (targetElement && domSafetyManager.isValidElement(targetElement)) {
          return targetElement;
        }
        if (useStoredRange) {
          const element = this.findElementFromStoredRange();
          if (element && domSafetyManager.isValidElement(element)) {
            return element;
          }
        }
        const currentElement = this.findElementFromCurrentSelection();
        if (currentElement && domSafetyManager.isValidElement(currentElement)) {
          return currentElement;
        }
        const fallbackElement = this.findElementBySelectors();
        if (fallbackElement && domSafetyManager.isValidElement(fallbackElement)) {
          return fallbackElement;
        }
        return null;
      } catch (error) {
        console.error("Error finding target element:", error);
        return null;
      }
    }
    /**
     * Finds element from stored selection range
     * @returns {HTMLElement|null} Element or null if not found
     * @private
     */
    findElementFromStoredRange() {
      const selectionInfo = textSelectionManager.getCurrentSelection();
      if ((selectionInfo == null ? void 0 : selectionInfo.range) && (selectionInfo == null ? void 0 : selectionInfo.element)) {
        return findEditableParent(selectionInfo.range.commonAncestorContainer);
      }
      return null;
    }
    /**
     * Finds element from current selection
     * @returns {HTMLElement|null} Element or null if not found
     * @private
     */
    findElementFromCurrentSelection() {
      const selection = window.getSelection();
      if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        return findEditableParent(range.commonAncestorContainer);
      }
      return null;
    }
    /**
     * Finds element using common selectors
     * @returns {HTMLElement|null} Element or null if not found
     * @private
     */
    findElementBySelectors() {
      return findEditableElementBySelectors(SELECTORS.TEXT_INPUTS);
    }
    /**
     * Replaces text specifically for modal operations
     * @param {string} newText - New text to insert
     * @param {string} selectedText - Original selected text
     * @param {HTMLElement} targetElement - Target element
     * @returns {Promise<ReplacementResult>} Replacement result
     */
    async replaceTextFromModal(newText, selectedText, targetElement) {
      if (!domSafetyManager.isValidElement(targetElement)) {
        return {
          success: false,
          error: "No valid target element provided"
        };
      }
      if (typeof newText !== "string") {
        return {
          success: false,
          error: "Invalid text provided for replacement"
        };
      }
      try {
        if (!domSafetyManager.isElementVisible(targetElement)) {
          console.warn("Target element is not visible");
        }
        if (!domSafetyManager.safeFocus(targetElement)) {
          console.warn("Failed to focus target element, continuing anyway");
        }
        const result = await this.siteHandler.replaceText(
          targetElement,
          newText,
          {
            showFeedback: false
            // We'll show feedback separately
          }
        );
        if (result.success) {
          try {
            await visualFeedbackManager.showTextReplacementFeedback(targetElement);
          } catch (feedbackError) {
            console.warn("Visual feedback failed:", feedbackError);
          }
        }
        return result;
      } catch (error) {
        console.error("Modal text replacement failed:", error);
        return {
          success: false,
          error: error.message || "Modal replacement failed"
        };
      }
    }
    /**
     * Gets information about the current site handler
     * @returns {string} Site handler name
     */
    getSiteHandlerInfo() {
      return this.siteHandler.siteName;
    }
    /**
     * Refreshes the site handler (useful if the page URL changes)
     */
    refreshSiteHandler() {
      this.siteHandler = SiteHandlerFactory.createHandler();
    }
    /**
     * Validates if text replacement is possible
     * @param {HTMLElement} [targetElement] - Optional target element to check
     * @returns {Promise<{valid: boolean, reason?: string}>} Validation result
     */
    async validateReplacement(targetElement = null) {
      try {
        const element = await this.findTargetElement(targetElement, false);
        if (!domSafetyManager.isValidElement(element)) {
          return {
            valid: false,
            reason: "No valid editable element found"
          };
        }
        if (!domSafetyManager.isElementVisible(element)) {
          return {
            valid: false,
            reason: "Target element is not visible"
          };
        }
        if (element.disabled || element.readOnly) {
          return {
            valid: false,
            reason: "Target element is disabled or readonly"
          };
        }
        if (!element.isConnected) {
          return {
            valid: false,
            reason: "Target element is not connected to the DOM"
          };
        }
        return { valid: true };
      } catch (error) {
        console.error("Validation error:", error);
        return {
          valid: false,
          reason: `Validation error: ${error.message}`
        };
      }
    }
  };
  var textReplacementManager = new TextReplacementManager();

  // src/content/modules/modalStyles.js
  var ModalStyleManager = class {
    constructor() {
      this.stylesInjected = false;
    }
    /**
     * Ensures modal styles are added to the page
     * @returns {void}
     */
    ensureModalStyles() {
      if (this.stylesInjected)
        return;
      const styleId = CSS_CLASSES.MODAL_STYLES;
      if (document.getElementById(styleId)) {
        this.stylesInjected = true;
        return;
      }
      const style = document.createElement("style");
      style.id = styleId;
      style.textContent = this.getModalCSS();
      document.head.appendChild(style);
      this.stylesInjected = true;
    }
    /**
     * Gets the complete CSS for modal components
     * @returns {string} CSS content
     * @private
     */
    getModalCSS() {
      return `
      ${this.getFontImports()}
      ${this.getModalOverlayStyles()}
      ${this.getModalContentStyles()}
      ${this.getHeaderStyles()}
      ${this.getSearchStyles()}
      ${this.getTemplateListStyles()}
      ${this.getTemplateItemStyles()}
      ${this.getTypeBadgeStyles()}
      ${this.getFooterStyles()}
      ${this.getAnimationStyles()}
    `;
    }
    /**
     * Font imports for modal
     * @returns {string} CSS font imports
     * @private
     */
    getFontImports() {
      return `
      @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&family=IBM+Plex+Mono:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600;1,700&display=swap');
    `;
    }
    /**
     * Modal overlay styles
     * @returns {string} CSS for modal overlay
     * @private
     */
    getModalOverlayStyles() {
      return `
      .${CSS_CLASSES.MODAL_OVERLAY} {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: ${Z_INDEX.MODAL_OVERLAY};
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: 'Plus Jakarta Sans', sans-serif;
        letter-spacing: -0.025em;
      }
    `;
    }
    /**
     * Modal content container styles
     * @returns {string} CSS for modal content
     * @private
     */
    getModalContentStyles() {
      return `
      .${CSS_CLASSES.MODAL} {
        background: oklch(0.994 0 0);
        border: 1px solid oklch(0.93 0.0094 286.2156);
        border-radius: 1.4rem;
        box-shadow: 0px 8px 10px -1px hsl(0 0% 0% / 0.16), 0px 2px 3px 0px hsl(0 0% 0% / 0.16);
        width: 90%;
        max-width: 480px;
        max-height: 80vh;
        overflow: hidden;
        animation: prompter-modal-enter 0.2s ease-out;
      }
    `;
    }
    /**
     * Modal header styles
     * @returns {string} CSS for modal header
     * @private
     */
    getHeaderStyles() {
      return `
      .prompter-header {
        padding: 20px 20px 16px;
        border-bottom: 1px solid oklch(0.93 0.0094 286.2156);
      }

      .prompter-header h3 {
        margin: 0 0 12px 0;
        font-size: 18px;
        font-weight: 600;
        color: oklch(0 0 0);
      }
    `;
    }
    /**
     * Search input styles
     * @returns {string} CSS for search input
     * @private
     */
    getSearchStyles() {
      return `
      .prompter-search {
        width: 100%;
        padding: 8px 12px;
        border: 1px solid oklch(0.93 0.0094 286.2156);
        border-radius: calc(1.4rem - 8px);
        font-size: 14px;
        outline: none;
        box-sizing: border-box;
        background: oklch(0.9401 0 0);
        color: oklch(0 0 0);
        font-family: 'Plus Jakarta Sans', sans-serif;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
      }

      .prompter-search:focus {
        border-color: ${COLORS.INFO};
        box-shadow: 0 0 0 3px oklch(0.5393 0.2713 286.7462 / 0.1);
      }

      .prompter-search::placeholder {
        color: oklch(0.6 0 0);
      }
    `;
    }
    /**
     * Template list container styles
     * @returns {string} CSS for template list
     * @private
     */
    getTemplateListStyles() {
      return `
      .prompter-template-list {
        max-height: 300px;
        overflow-y: auto;
        padding: 8px;
        scrollbar-width: thin;
        scrollbar-color: oklch(0.7 0 0) transparent;
      }

      .prompter-template-list::-webkit-scrollbar {
        width: 6px;
      }

      .prompter-template-list::-webkit-scrollbar-track {
        background: transparent;
      }

      .prompter-template-list::-webkit-scrollbar-thumb {
        background-color: oklch(0.7 0 0);
        border-radius: 3px;
      }

      .prompter-empty {
        text-align: center;
        padding: 40px 20px;
        color: oklch(0.4386 0 0);
        font-size: 14px;
      }
    `;
    }
    /**
     * Template item styles
     * @returns {string} CSS for template items
     * @private
     */
    getTemplateItemStyles() {
      return `
      .${CSS_CLASSES.TEMPLATE_ITEM} {
        display: flex;
        align-items: center;
        padding: 12px 16px;
        margin: 4px 0;
        border-radius: calc(1.4rem - 6px);
        cursor: pointer;
        transition: all 0.15s ease;
        position: relative;
        background: oklch(0.994 0 0);
        border: 1px solid transparent;
      }

      .${CSS_CLASSES.TEMPLATE_ITEM}:hover {
        background-color: oklch(0.9702 0);
        border: 1px solid oklch(0.93 0.0094 286.2156);
        box-shadow: 0px 2px 3px 0px hsl(0 0% 0% / 0.08);
        transform: translateY(-1px);
      }

      .${CSS_CLASSES.TEMPLATE_ITEM}.${CSS_CLASSES.TEMPLATE_SELECTED} {
        background-color: oklch(0.9393 0.0288 266.368);
        border-color: ${COLORS.INFO};
        box-shadow: 0px 2px 3px 0px hsl(0 0% 0% / 0.16), 0px 1px 2px -1px hsl(0 0% 0% / 0.16);
        transform: translateY(-1px);
      }

      .prompter-template-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 2px;
        width: 100%;
      }

      .prompter-template-name {
        font-weight: 500;
        color: oklch(0 0 0);
        flex: 1;
        font-size: 14px;
      }

      .prompter-template-badges {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .prompter-source-badge {
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 4px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }

      .prompter-source-badge-free {
        background: oklch(0.5568 0.2294 142.495 / 0.15);
        color: oklch(0.5568 0.2294 142.495);
      }

      .prompter-source-badge-pro {
        background: oklch(0.5393 0.2713 286.7462 / 0.15);
        color: oklch(0.5393 0.2713 286.7462);
      }

      .prompter-template-description {
        font-size: 13px;
        color: oklch(0.4386 0 0);
        flex: 1;
        margin-top: 2px;
        line-height: 1.3;
      }

      .prompter-template-number {
        position: absolute;
        top: 8px;
        right: 8px;
        background: oklch(0.9702 0 0);
        color: oklch(0.4386 0 0);
        font-size: 11px;
        font-weight: 500;
        padding: 2px 6px;
        border-radius: calc(1.4rem - 10px);
        min-width: 16px;
        text-align: center;
        transition: all 0.15s ease;
      }

      .${CSS_CLASSES.TEMPLATE_ITEM}.${CSS_CLASSES.TEMPLATE_SELECTED} .prompter-template-number {
        background: ${COLORS.INFO};
        color: ${COLORS.WHITE};
      }
    `;
    }
    /**
     * Type badge styles for different template types
     * @returns {string} CSS for type badges
     * @private
     */
    getTypeBadgeStyles() {
      return `
      .prompter-type-badge {
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 4px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        transition: all 0.15s ease;
      }

      .prompter-type-json {
        background: oklch(0.4792 0.2202 231.6067 / 0.1);
        color: oklch(0.4792 0.2202 231.6067);
      }

      .prompter-type-xml {
        background: oklch(0.5568 0.2294 142.495 / 0.1);
        color: oklch(0.5568 0.2294 142.495);
      }

      .prompter-type-markdown {
        background: oklch(0.5393 0.2713 286.7462 / 0.1);
        color: oklch(0.5393 0.2713 286.7462);
      }

      .prompter-type-text {
        background: oklch(0.6 0 0 / 0.1);
        color: oklch(0.6 0 0);
      }
    `;
    }
    /**
     * Modal footer styles
     * @returns {string} CSS for modal footer
     * @private
     */
    getFooterStyles() {
      return `
      .prompter-footer {
        padding: 12px 20px;
        background: oklch(0.9702 0 0);
        border-top: 1px solid oklch(0.93 0.0094 286.2156);
      }

      .prompter-hints {
        font-size: 12px;
        color: oklch(0.4386 0 0);
        text-align: center;
        display: block;
        line-height: 1.4;
      }

      .prompter-loading {
        text-align: center;
        padding: 20px;
        color: oklch(0.4386 0 0);
        font-size: 14px;
      }

      .prompter-loading::after {
        content: '';
        display: inline-block;
        width: 20px;
        height: 20px;
        margin-left: 8px;
        border: 3px solid oklch(0.7 0 0);
        border-top: 3px solid ${COLORS.INFO};
        border-radius: 50%;
        animation: prompter-loading-spin 1s linear infinite;
      }

      .prompter-success {
        text-align: center;
        padding: 20px;
        color: oklch(0.5568 0.2294 142.495);
        font-size: 14px;
        font-weight: 500;
        animation: prompter-success-fade-in 0.3s ease-out;
      }

      .prompter-success-content {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
      }
    `;
    }
    /**
     * Animation keyframes
     * @returns {string} CSS animations
     * @private
     */
    getAnimationStyles() {
      return `
      @keyframes prompter-modal-enter {
        from {
          opacity: 0;
          transform: scale(0.95) translateY(-10px);
        }
        to {
          opacity: 1;
          transform: scale(1) translateY(0);
        }
      }

      @keyframes prompter-modal-exit {
        from {
          opacity: 1;
          transform: scale(1) translateY(0);
        }
        to {
          opacity: 0;
          transform: scale(0.95) translateY(-10px);
        }
      }

      @keyframes prompter-loading-spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }

      @keyframes prompter-success-fade-in {
        from {
          opacity: 0;
          transform: translateY(-10px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      @keyframes prompter-pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
      }
    `;
    }
    /**
     * Removes modal styles from the page
     * @returns {void}
     */
    removeStyles() {
      const existingStyles = document.getElementById(CSS_CLASSES.MODAL_STYLES);
      if (existingStyles) {
        existingStyles.remove();
        this.stylesInjected = false;
      }
    }
  };
  var modalStyleManager = new ModalStyleManager();

  // src/content/modules/templateRenderer.js
  var TemplateRenderer = class {
    constructor() {
      this.allTemplates = [];
      this.filteredTemplates = [];
      this.selectedIndex = 0;
    }
    /**
     * Sets the templates to be rendered
     * @param {Template[]} templates - Array of templates
     * @returns {void}
     */
    setTemplates(templates) {
      this.allTemplates = templates || [];
      this.filteredTemplates = [...this.allTemplates];
      this.selectedIndex = 0;
    }
    /**
     * Filters templates based on search query
     * @param {string} query - Search query
     * @returns {Template[]} Filtered templates
     * @example
     * ```javascript
     * const results = renderer.filterTemplates('json');
     * ```
     */
    filterTemplates(query) {
      const normalizedQuery = query.toLowerCase().trim();
      if (normalizedQuery === "") {
        this.filteredTemplates = [...this.allTemplates];
      } else {
        this.filteredTemplates = this.allTemplates.filter(
          (template) => this.templateMatchesQuery(template, normalizedQuery)
        );
      }
      this.selectedIndex = 0;
      return this.filteredTemplates;
    }
    /**
     * Checks if a template matches the search query
     * @param {Template} template - Template to check
     * @param {string} query - Normalized search query
     * @returns {boolean} True if template matches
     * @private
     */
    templateMatchesQuery(template, query) {
      const searchFields = [
        template.name,
        template.description,
        template.templateType || template.template_type,
        template.promptTemplate || template.prompt_template
      ];
      return searchFields.some(
        (field) => field && field.toLowerCase().includes(query)
      );
    }
    /**
     * Renders the template list HTML
     * @returns {string} HTML string for template list
     */
    renderTemplateList() {
      if (this.filteredTemplates.length === 0) {
        return this.renderEmptyState();
      }
      return this.filteredTemplates.map((template, index) => this.renderTemplateItem(template, index)).join("");
    }
    /**
     * Renders a single template item
     * @param {Template} template - Template to render
     * @param {number} index - Template index in filtered list
     * @returns {string} HTML string for template item
     * @private
     */
    renderTemplateItem(template, index) {
      const templateType = this.getTemplateType(template);
      const isSelected = index === this.selectedIndex;
      const quickSelectNumber = index + 1;
      return `
      <div class="${CSS_CLASSES.TEMPLATE_ITEM} ${isSelected ? CSS_CLASSES.TEMPLATE_SELECTED : ""}" 
           data-index="${index}"
           data-template-id="${escapeHtml(template.id)}"
           role="option"
           aria-selected="${isSelected}"
           tabindex="${isSelected ? 0 : -1}">
        <div class="prompter-template-content">
          <div class="prompter-template-header">
            <div class="prompter-template-name" title="${escapeHtml(
        template.name
      )}">
              ${this.renderSourceIndicator(template)}${escapeHtml(template.name)}
            </div>
            <div class="prompter-template-badges">
              ${this.renderSourceBadge(template)}
              <span class="prompter-type-badge prompter-type-${templateType.toLowerCase()}" 
                    title="Template type: ${templateType}">
                ${templateType.toUpperCase()}
              </span>
            </div>
          </div>
          ${this.renderTemplateDescription(template)}
        </div>
        <div class="prompter-template-number" title="Press ${quickSelectNumber} to select">
          ${quickSelectNumber <= 9 ? quickSelectNumber : ""}
        </div>
      </div>
    `;
    }
    /**
     * Renders template description if available
     * @param {Template} template - Template object
     * @returns {string} HTML string for description or empty string
     * @private
     */
    renderTemplateDescription(template) {
      const description = template.description;
      if (!description || description.trim() === "") {
        return "";
      }
      const truncatedDescription = this.truncateText(description, 120);
      return `
      <div class="prompter-template-description" title="${escapeHtml(
        description
      )}">
        ${escapeHtml(truncatedDescription)}
      </div>
    `;
    }
    /**
     * Gets the template type with fallbacks
     * @param {Template} template - Template object
     * @returns {string} Template type
     * @private
     */
    getTemplateType(template) {
      return template.templateType || template.template_type || "text";
    }
    /**
     * Renders source indicator prefix for template name
     * @param {Template} template - Template object
     * @returns {string} HTML string for source indicator
     * @private
     */
    renderSourceIndicator(template) {
      if (template.source === "promptr") {
        return template.isFree === false ? "\u{1F512} " : "\u2728 ";
      }
      return "";
    }
    /**
     * Renders source badge for template
     * @param {Template} template - Template object
     * @returns {string} HTML string for source badge
     * @private
     */
    renderSourceBadge(template) {
      if (template.source === "promptr") {
        const badgeClass = template.isFree === false ? "prompter-source-badge-pro" : "prompter-source-badge-free";
        const badgeText = template.isFree === false ? "PRO" : "FREE";
        const badgeTitle = template.isFree === false ? "Pro template - requires Pro subscription" : "Free promptr template";
        return `
        <span class="prompter-source-badge ${badgeClass}" 
              title="${badgeTitle}">
          ${badgeText}
        </span>
      `;
      }
      return "";
    }
    /**
     * Truncates text to specified length with ellipsis
     * @param {string} text - Text to truncate
     * @param {number} maxLength - Maximum length
     * @returns {string} Truncated text
     * @private
     */
    truncateText(text, maxLength) {
      if (text.length <= maxLength) {
        return text;
      }
      return text.substring(0, maxLength - 3) + "...";
    }
    /**
     * Renders empty state when no templates match
     * @returns {string} HTML string for empty state
     * @private
     */
    renderEmptyState() {
      return `
      <div class="prompter-empty" role="status">
        <div>No templates found</div>
        <div style="font-size: 12px; margin-top: 8px; opacity: 0.7;">
          Try adjusting your search terms
        </div>
      </div>
    `;
    }
    /**
     * Renders loading state
     * @returns {string} HTML string for loading state
     */
    renderLoadingState() {
      return `
      <div class="prompter-loading" role="status" aria-live="polite">
        <div>Formatting text...</div>
      </div>
    `;
    }
    /**
     * Renders text replacement progress state
     * @returns {string} HTML string for replacement progress
     */
    renderReplacementProgress() {
      return `
      <div class="prompter-loading" role="status" aria-live="polite">
        <div>Replacing text...</div>
      </div>
    `;
    }
    /**
     * Renders success state
     * @returns {string} HTML string for success state
     */
    renderSuccessState() {
      return `
      <div class="prompter-success" role="status" aria-live="polite">
        <div class="prompter-success-content">\u2705 Text replaced successfully!</div>
      </div>
    `;
    }
    /**
     * Moves selection up or down
     * @param {number} direction - Direction to move (-1 for up, 1 for down)
     * @returns {boolean} True if selection changed
     */
    moveSelection(direction) {
      const newIndex = this.selectedIndex + direction;
      if (newIndex >= 0 && newIndex < this.filteredTemplates.length) {
        this.selectedIndex = newIndex;
        return true;
      }
      return false;
    }
    /**
     * Gets the currently selected template
     * @returns {Template|null} Selected template or null if none
     */
    getSelectedTemplate() {
      if (this.selectedIndex >= 0 && this.selectedIndex < this.filteredTemplates.length) {
        return this.filteredTemplates[this.selectedIndex];
      }
      return null;
    }
    /**
     * Selects template by index
     * @param {number} index - Index to select
     * @returns {boolean} True if selection was successful
     */
    selectByIndex(index) {
      if (index >= 0 && index < this.filteredTemplates.length) {
        this.selectedIndex = index;
        return true;
      }
      return false;
    }
    /**
     * Gets template by quick select number (1-9)
     * @param {number} number - Quick select number (1-9)
     * @returns {Template|null} Template or null if not found
     */
    getTemplateByQuickSelect(number) {
      const index = number - 1;
      if (index >= 0 && index < this.filteredTemplates.length && index <= 8) {
        return this.filteredTemplates[index];
      }
      return null;
    }
    /**
     * Gets the current selection state
     * @returns {{selectedIndex: number, selectedTemplate: Template|null, totalCount: number}}
     */
    getSelectionState() {
      return {
        selectedIndex: this.selectedIndex,
        selectedTemplate: this.getSelectedTemplate(),
        totalCount: this.filteredTemplates.length
      };
    }
    /**
     * Resets the renderer state
     * @returns {void}
     */
    reset() {
      this.allTemplates = [];
      this.filteredTemplates = [];
      this.selectedIndex = 0;
    }
    /**
     * Gets statistics about templates
     * @returns {{total: number, filtered: number, types: Object<string, number>}}
     */
    getStatistics() {
      const types = {};
      this.allTemplates.forEach((template) => {
        const type = this.getTemplateType(template);
        types[type] = (types[type] || 0) + 1;
      });
      return {
        total: this.allTemplates.length,
        filtered: this.filteredTemplates.length,
        types
      };
    }
  };
  var templateRenderer = new TemplateRenderer();

  // src/content/modules/modalManager.js
  var ModalManager = class {
    constructor() {
      this.modalElement = null;
      this.searchInput = null;
      this.selectedText = "";
      this.targetElement = null;
      this.isVisible = false;
      this.eventController = null;
    }
    /**
     * Shows the modal with provided configuration
     * @param {ModalConfig} config - Modal configuration
     * @returns {Promise<void>}
     * @example
     * ```javascript
     * await modalManager.show({
     *   templates: userTemplates,
     *   selectedText: 'Hello world',
     *   targetElement: inputElement
     * });
     * ```
     */
    async show(config) {
      if (this.isVisible) {
        await this.close();
      }
      const validationResult = this.validateConfig(config);
      if (!validationResult.valid) {
        throw new Error(validationResult.error);
      }
      this.selectedText = config.selectedText;
      this.targetElement = config.targetElement;
      templateRenderer.setTemplates(config.templates);
      modalStyleManager.ensureModalStyles();
      await this.createModal();
      this.setupEventListeners();
      this.attachToPage();
      this.focusSearchInput();
      this.isVisible = true;
    }
    /**
     * Validates modal configuration
     * @param {ModalConfig} config - Configuration to validate
     * @returns {{valid: boolean, error?: string}} Validation result
     * @private
     */
    validateConfig(config) {
      if (config.error) {
        if (config.error.includes("authenticated")) {
          visualFeedbackManager.showError(
            "Please sign in to use templates. Open the extension popup to authenticate."
          );
        } else {
          visualFeedbackManager.showError(config.error);
        }
        return { valid: false, error: config.error };
      }
      if (!config.selectedText || config.selectedText.trim().length === 0) {
        const error = "Please select text first";
        visualFeedbackManager.showError(error);
        return { valid: false, error };
      }
      if (!config.targetElement) {
        const error = "Please select text in an input field";
        visualFeedbackManager.showError(error);
        return { valid: false, error };
      }
      return { valid: true };
    }
    /**
     * Creates the modal DOM structure
     * @returns {Promise<void>}
     * @private
     */
    async createModal() {
      try {
        this.modalElement = document.createElement("div");
        if (!domSafetyManager.isValidElement(this.modalElement)) {
          throw new Error("Failed to create modal element");
        }
        this.modalElement.className = CSS_CLASSES.MODAL_OVERLAY;
        domSafetyManager.safeSetAttribute(this.modalElement, "role", "dialog");
        domSafetyManager.safeSetAttribute(this.modalElement, "aria-modal", "true");
        domSafetyManager.safeSetAttribute(this.modalElement, "aria-labelledby", "prompter-modal-title");
        const modalContent = `
        <div class="${CSS_CLASSES.MODAL}" role="document">
          <div class="prompter-header">
            <h3 id="prompter-modal-title">Select Template</h3>
            <input type="text" 
                   class="prompter-search" 
                   placeholder="Type to search templates..." 
                   autocomplete="off"
                   aria-label="Search templates"
                   aria-describedby="prompter-search-hint">
            <div id="prompter-search-hint" class="sr-only">
              Use arrow keys to navigate, Enter to select, Esc to close
            </div>
          </div>
          <div class="prompter-template-list" 
               role="listbox" 
               aria-label="Available templates"
               tabindex="-1">
            ${templateRenderer.renderTemplateList()}
          </div>
          <div class="prompter-footer">
            <span class="prompter-hints">
              \u2191\u2193 Navigate \u2022 Enter Select \u2022 Esc Close \u2022 1-9 Quick Select
            </span>
          </div>
        </div>
      `;
        try {
          this.modalElement.innerHTML = modalContent;
        } catch (htmlError) {
          console.error("Failed to set modal HTML:", htmlError);
          throw new Error("Failed to set modal content");
        }
        this.searchInput = this.modalElement.querySelector(".prompter-search");
        if (!this.searchInput) {
          console.error("\u274C Search input not found in modal HTML");
          console.error("Modal HTML length:", this.modalElement.innerHTML.length);
          console.error("Modal HTML preview:", this.modalElement.innerHTML.substring(0, 500));
          console.error("All inputs in modal:", this.modalElement.querySelectorAll("input"));
          console.error("Elements with 'search' class:", this.modalElement.querySelectorAll(".prompter-search"));
          throw new Error("Failed to find search input element");
        }
      } catch (error) {
        console.error("Modal creation failed:", error);
        throw error;
      }
    }
    /**
     * Sets up event listeners for modal interaction
     * @returns {void}
     * @private
     */
    setupEventListeners() {
      this.eventController = new AbortController();
      const { signal } = this.eventController;
      if (this.searchInput) {
        this.searchInput.addEventListener("input", this.handleSearch.bind(this), {
          signal
        });
        this.searchInput.addEventListener(
          "keydown",
          this.handleKeyDown.bind(this),
          { signal }
        );
      }
      this.modalElement.addEventListener(
        "click",
        this.handleBackdropClick.bind(this),
        { signal }
      );
      this.setupTemplateItemListeners(signal);
      document.addEventListener("keydown", this.handleGlobalKeyDown.bind(this), {
        signal
      });
    }
    /**
     * Sets up click listeners for template items
     * @param {AbortSignal} signal - Abort signal for cleanup
     * @returns {void}
     * @private
     */
    setupTemplateItemListeners(signal) {
      const templateItems = this.modalElement.querySelectorAll(
        `.${CSS_CLASSES.TEMPLATE_ITEM}`
      );
      templateItems.forEach((item, index) => {
        item.addEventListener(
          "click",
          () => {
            this.selectTemplateByIndex(index);
          },
          { signal }
        );
        item.addEventListener(
          "mouseenter",
          () => {
            templateRenderer.selectByIndex(index);
            this.updateSelectionDisplay();
          },
          { signal }
        );
      });
    }
    /**
     * Handles search input
     * @param {Event} event - Input event
     * @returns {void}
     * @private
     */
    handleSearch(event) {
      const query = event.target.value;
      templateRenderer.filterTemplates(query);
      this.updateTemplateListContent();
    }
    /**
     * Handles keydown events in search input
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {void}
     * @private
     */
    handleKeyDown(event) {
      switch (event.key) {
        case "ArrowDown":
          event.preventDefault();
          this.moveSelection(1);
          break;
        case "ArrowUp":
          event.preventDefault();
          this.moveSelection(-1);
          break;
        case "Enter":
          event.preventDefault();
          this.selectCurrentTemplate();
          break;
        case "Escape":
          event.preventDefault();
          this.close();
          break;
        case "Tab":
          event.preventDefault();
          this.moveSelection(event.shiftKey ? -1 : 1);
          break;
        default:
          if (event.key >= "1" && event.key <= "9") {
            event.preventDefault();
            const number = parseInt(event.key);
            this.selectTemplateByQuickSelect(number);
          }
          break;
      }
    }
    /**
     * Handles global keydown events
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {void}
     * @private
     */
    handleGlobalKeyDown(event) {
      if (event.key === "Escape" && this.isVisible) {
        event.preventDefault();
        event.stopPropagation();
        this.close();
      }
    }
    /**
     * Handles backdrop click to close modal
     * @param {Event} event - Click event
     * @returns {void}
     * @private
     */
    handleBackdropClick(event) {
      if (event.target === this.modalElement) {
        this.close();
      }
    }
    /**
     * Moves selection up or down
     * @param {number} direction - Direction to move (-1 for up, 1 for down)
     * @returns {void}
     * @private
     */
    moveSelection(direction) {
      if (templateRenderer.moveSelection(direction)) {
        this.updateSelectionDisplay();
        this.scrollSelectedIntoView();
      }
    }
    /**
     * Updates the visual selection display
     * @returns {void}
     * @private
     */
    updateSelectionDisplay() {
      const templateItems = this.modalElement.querySelectorAll(
        `.${CSS_CLASSES.TEMPLATE_ITEM}`
      );
      const { selectedIndex } = templateRenderer.getSelectionState();
      templateItems.forEach((item, index) => {
        const isSelected = index === selectedIndex;
        item.classList.toggle(CSS_CLASSES.TEMPLATE_SELECTED, isSelected);
        item.setAttribute("aria-selected", isSelected);
        item.setAttribute("tabindex", isSelected ? 0 : -1);
      });
    }
    /**
     * Scrolls the selected item into view
     * @returns {void}
     * @private
     */
    scrollSelectedIntoView() {
      const selectedItem = this.modalElement.querySelector(
        `.${CSS_CLASSES.TEMPLATE_ITEM}.${CSS_CLASSES.TEMPLATE_SELECTED}`
      );
      if (selectedItem) {
        selectedItem.scrollIntoView({
          block: "nearest",
          behavior: "smooth"
        });
      }
    }
    /**
     * Updates the template list display (only called when search changes)
     * @returns {void}
     * @private
     */
    updateTemplateList() {
      const templateList = this.modalElement.querySelector(
        ".prompter-template-list"
      );
      if (templateList) {
        templateList.innerHTML = templateRenderer.renderTemplateList();
        this.setupTemplateItemListeners(this.eventController.signal);
        this.updateSelectionDisplay();
      }
    }
    /**
     * Updates only the template list content without affecting modal structure
     * @returns {void}
     * @private
     */
    updateTemplateListContent() {
      const templateList = this.modalElement.querySelector(
        ".prompter-template-list"
      );
      if (templateList) {
        const scrollTop = templateList.scrollTop;
        templateList.innerHTML = templateRenderer.renderTemplateList();
        this.setupTemplateItemListeners(this.eventController.signal);
        this.updateSelectionDisplay();
        templateList.scrollTop = scrollTop;
      }
    }
    /**
     * Selects template by index
     * @param {number} index - Template index
     * @returns {Promise<void>}
     * @private
     */
    async selectTemplateByIndex(index) {
      if (templateRenderer.selectByIndex(index)) {
        await this.selectCurrentTemplate();
      }
    }
    /**
     * Selects template by quick select number
     * @param {number} number - Quick select number (1-9)
     * @returns {Promise<void>}
     * @private
     */
    async selectTemplateByQuickSelect(number) {
      const template = templateRenderer.getTemplateByQuickSelect(number);
      if (template) {
        await this.processTemplateSelection(template);
      }
    }
    /**
     * Selects the currently highlighted template
     * @returns {Promise<void>}
     * @private
     */
    async selectCurrentTemplate() {
      const selectedTemplate = templateRenderer.getSelectedTemplate();
      if (selectedTemplate) {
        await this.processTemplateSelection(selectedTemplate);
      }
    }
    /**
     * Processes template selection and formats text with enhanced visual feedback
     * @param {Template} template - Selected template
     * @returns {Promise<void>}
     * @private
     */
    async processTemplateSelection(template) {
      try {
        this.showLoadingState();
        const response = await this.requestTextFormatting(template);
        if (response.error) {
          throw new Error(response.error);
        }
        this.showReplacementProgress();
        await this.replaceTextWithResult(response.formattedText);
        this.showSuccessAndClose();
      } catch (error) {
        console.error("Template selection failed:", error);
        visualFeedbackManager.showError(error.message || "Failed to format text");
        await this.close();
      }
    }
    /**
     * Requests text formatting from background script
     * @param {Template} template - Template to use for formatting
     * @returns {Promise<string>} Formatted text
     * @private
     */
    async requestTextFormatting(template) {
      try {
        const formattedText = await backgroundCommunicator.formatText(
          template.id,
          this.selectedText
        );
        return { formattedText };
      } catch (error) {
        console.error("Text formatting failed:", error);
        throw error;
      }
    }
    /**
     * Replaces text with formatted result
     * @param {string} formattedText - Formatted text to insert
     * @returns {Promise<void>}
     * @private
     */
    async replaceTextWithResult(formattedText) {
      if (!formattedText || !this.targetElement) {
        throw new Error("No formatted text or target element");
      }
      const result = await textReplacementManager.replaceTextFromModal(
        formattedText,
        this.selectedText,
        this.targetElement
      );
      if (!result.success) {
        throw new Error(result.error || "Text replacement failed");
      }
    }
    /**
     * Shows loading state in modal
     * @returns {void}
     * @private
     */
    showLoadingState() {
      const templateList = this.modalElement.querySelector(
        ".prompter-template-list"
      );
      if (templateList) {
        templateList.innerHTML = templateRenderer.renderLoadingState();
      }
    }
    /**
     * Shows text replacement progress in modal
     * @returns {void}
     * @private
     */
    showReplacementProgress() {
      const templateList = this.modalElement.querySelector(
        ".prompter-template-list"
      );
      if (templateList) {
        templateList.innerHTML = templateRenderer.renderReplacementProgress();
      }
    }
    /**
     * Shows success state and closes modal after delay
     * @returns {void}
     * @private
     */
    showSuccessAndClose() {
      const templateList = this.modalElement.querySelector(
        ".prompter-template-list"
      );
      if (templateList) {
        templateList.innerHTML = templateRenderer.renderSuccessState();
      }
      setTimeout(() => {
        this.close();
      }, 600);
    }
    /**
     * Attaches modal to page
     * @returns {void}
     * @private
     */
    attachToPage() {
      try {
        if (!domSafetyManager.isValidElement(this.modalElement)) {
          throw new Error("Invalid modal element");
        }
        if (!document.body) {
          throw new Error("Document body not available");
        }
        document.body.appendChild(this.modalElement);
      } catch (error) {
        console.error("Failed to attach modal to page:", error);
        throw error;
      }
    }
    /**
     * Focuses the search input
     * @returns {void}
     * @private
     */
    focusSearchInput() {
      if (domSafetyManager.isValidElement(this.searchInput)) {
        requestAnimationFrame(() => {
          if (!domSafetyManager.safeFocus(this.searchInput)) {
            console.warn("Failed to focus search input");
          }
        });
      } else {
        console.warn("Search input element is not valid for focusing");
      }
    }
    /**
     * Closes the modal
     * @returns {Promise<void>}
     */
    async close() {
      if (!this.isVisible)
        return;
      try {
        if (this.eventController) {
          this.eventController.abort();
          this.eventController = null;
        }
        if (domSafetyManager.isValidElement(this.modalElement)) {
          this.modalElement.style.animation = "prompter-modal-exit 0.2s ease-out";
          await new Promise((resolve) => {
            setTimeout(() => {
              if (domSafetyManager.isValidElement(this.modalElement)) {
                domSafetyManager.safeRemoveElement(this.modalElement);
              }
              resolve();
            }, 200);
          });
        }
      } catch (error) {
        console.error("Error during modal close:", error);
      }
      this.modalElement = null;
      this.searchInput = null;
      this.selectedText = "";
      this.targetElement = null;
      this.isVisible = false;
      templateRenderer.reset();
    }
    /**
     * Checks if modal is currently visible
     * @returns {boolean} True if modal is visible
     */
    getIsVisible() {
      return this.isVisible;
    }
    /**
     * Gets current modal state for debugging
     * @returns {Object} Current modal state
     */
    getState() {
      return {
        isVisible: this.isVisible,
        hasTargetElement: !!this.targetElement,
        selectedText: this.selectedText,
        templateStats: templateRenderer.getStatistics()
      };
    }
  };
  var modalOpenTimeout = null;
  var lastModalOpenTime = 0;
  var MODAL_OPEN_DEBOUNCE = 500;
  async function handleKeyboardModal(message) {
    const now = Date.now();
    if (modalOpenTimeout) {
      clearTimeout(modalOpenTimeout);
    }
    if (now - lastModalOpenTime < MODAL_OPEN_DEBOUNCE) {
      modalOpenTimeout = setTimeout(() => {
        handleKeyboardModalImmediate(message);
      }, MODAL_OPEN_DEBOUNCE);
      return;
    }
    lastModalOpenTime = now;
    return handleKeyboardModalImmediate(message);
  }
  async function handleKeyboardModalImmediate(message) {
    var _a, _b, _c;
    if (message.error) {
      if (message.error.includes("authenticated")) {
        visualFeedbackManager.showError(
          "Please sign in to use templates. Open the extension popup to authenticate."
        );
      } else {
        visualFeedbackManager.showError(message.error);
      }
      return;
    }
    const selectionInfo = getCurrentSelection();
    if (!selectionInfo) {
      visualFeedbackManager.showError("Please select text first");
      return;
    }
    const targetElement = findEditableParent(selectionInfo.anchorNode);
    if (!targetElement) {
      console.error("\u274C findEditableParent returned null for:", {
        website: window.location.hostname,
        anchorNode: selectionInfo.anchorNode,
        anchorNodeHTML: (_c = (_b = (_a = selectionInfo.anchorNode) == null ? void 0 : _a.parentElement) == null ? void 0 : _b.outerHTML) == null ? void 0 : _c.substring(0, 200),
        selectionText: selectionInfo.text
      });
      visualFeedbackManager.showError("Please select text in an input field");
      return;
    }
    try {
      const freshTemplates = await backgroundCommunicator.getTemplates();
      await globalModalManager.show({
        templates: freshTemplates,
        selectedText: selectionInfo.text,
        targetElement,
        error: message.error
      });
    } catch (templatesError) {
      await globalModalManager.show({
        templates: message.templates || [],
        selectedText: selectionInfo.text,
        targetElement,
        error: message.error
      });
    }
  }
  var globalModalManager = new ModalManager();

  // src/content/index.js
  chrome.runtime.onMessage.addListener(
    errorHandler.wrapFunction(
      (message, sender, sendResponse) => {
        try {
          sendResponse({ received: true });
        } catch (responseError) {
          console.warn("Failed to send response:", responseError);
        }
        handleMessage(message).then(() => {
        }).catch((error) => {
          errorHandler.handleError(error, "messageHandling", { message });
          visualFeedbackManager.showUserFriendlyError(error, "messageHandling");
        });
        return true;
      },
      "messageListener",
      { retries: 0 }
      // Don't retry message handling
    )
  );
  async function handleMessage(message) {
    switch (message.action) {
      case ACTIONS.REPLACE_TEXT:
        await handleReplaceText(message);
        break;
      case ACTIONS.SHOW_LOADING:
        visualFeedbackManager.showLoading(message.message);
        break;
      case ACTIONS.SHOW_ERROR:
        visualFeedbackManager.showError(message.message);
        break;
      case ACTIONS.SHOW_KEYBOARD_MODAL:
        await handleKeyboardModal(message);
        break;
      case "formatComplete":
      case "formatError":
        backgroundCommunicator.handleDirectMessage(message);
        break;
      default:
        console.error("Unknown message action:", message.action);
    }
  }
  async function handleReplaceText(message) {
    if (!message.newText) {
      throw new Error("No text provided for replacement");
    }
    const result = await textReplacementManager.replaceSelectedText(
      message.newText,
      {
        showFeedback: true
      }
    );
    if (!result.success) {
      throw new Error(result.error || "Text replacement failed");
    }
  }
  async function validateSetup() {
    try {
      const hasSelection = textSelectionManager.hasValidSelection();
      const validationResult = await textReplacementManager.validateReplacement();
    } catch (error) {
      console.error("\u274C Setup validation failed:", error);
    }
  }
  function performanceMonitoring() {
  }
  function enhanceAccessibility() {
    const announceToScreenReader = (message) => {
      const announcement = document.createElement("div");
      announcement.setAttribute("aria-live", "polite");
      announcement.setAttribute("aria-atomic", "true");
      announcement.style.position = "absolute";
      announcement.style.left = "-10000px";
      announcement.style.width = "1px";
      announcement.style.height = "1px";
      announcement.style.overflow = "hidden";
      announcement.textContent = message;
      document.body.appendChild(announcement);
      setTimeout(() => {
        document.body.removeChild(announcement);
      }, 1e3);
    };
    window.prompterAnnounce = announceToScreenReader;
  }
  function setupErrorBoundary() {
    errorHandler.addErrorListener((error, context, metadata) => {
      if (context.includes("critical") || context.includes("modal")) {
        visualFeedbackManager.showUserFriendlyError(error, context);
      }
    });
  }
  async function initialize() {
    try {
      setupErrorBoundary();
      enhanceAccessibility();
      await validateSetup();
      performanceMonitoring();
    } catch (error) {
      console.error("\u274C Initialization failed:", error);
      visualFeedbackManager.showError("Extension failed to initialize properly");
    }
  }
  initialize();
  window.prompterManagers = {
    textSelection: textSelectionManager,
    textReplacement: textReplacementManager,
    visualFeedback: visualFeedbackManager
  };
})();
//# sourceMappingURL=content.js.map
